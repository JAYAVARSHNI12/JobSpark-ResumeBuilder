# 🎓 ResumeForge — CS Capstone Student Project

Welcome to **ResumeForge**, a premium, full-stack, ATS-friendly resume creation workshop submitted as a Computer Science Capstone project assignment. This application leverages **React + TypeScript + Tailwind CSS** on the frontend, with complete **Firebase Authentication and Cloud Firestore** powering persistent data storage, secured under deep Zero-Trust database access matrices.

---

## 🎯 Project Goals & Features

-   **Seamless Authentication**: Secure user logins using email credentials, alongside direct Google OAuth integrations.
-   **Zero-Trust Security**: Structured Firebase rules featuring atomic ID poison filters, strict map key-length bounds, temporal validations (`request.time`), and client-query list enforcements on the collection data.
-   **ATS Parsing Advisory Suite**: Real-time checking heuristics verifying if descriptions contain required keywords, whether employment dates match standard chronological guides, and providing direct tips to score 100%.
-   **Dynamic Style Engine**: Choose from 4 unique formats (Classic Serif, Modern Minimal Sidebar, Executive Bold, or Student Fresh) and watch the canvas respond reactive to key inputs.
-   **Lossless Switching**: Swap resume layouts seamlessly mid-session. All inputs are retained in React memory context.
-   **Vector PDF Generators**: Leverages standard layout scaling and `html2pdf.js` to download resumes instantly as professional PDF documents.
-   **Grader Demo Mode**: Built-in instant local storage database simulation to allow immediate testing by professors in gated sandbox environments.

---

## 💻 Tech Stack & Dependencies

-   **Frontend**: React (v19) utilizing customized React Hooks, Context APIs, and React Router (v6).
-   **Styling**: Full responsive constraints styled directly on Tailwind CSS.
-   **Database**: Google Cloud Firestore (Enterprise Edition).
-   **Authentication**: Firebase Security Authentication.
-   **Icons**: Lucide React.
-   **PDF Export**: `html2pdf.js` utilizing vector canvas conversions.

---

## 🗄️ Firestore Database Schemas

Our Firestore documents map directly onto the entities below:

### `users/{uid}` (User Profiles)
```json
{
  "uid": "USER_ID_TOKEN",
  "name": "Alex Mercer",
  "email": "alex.mercer@university.edu",
  "createdAt": "TIMESTAMP_OF_CREATION"
}
```

### `resumes/{resumeId}` (Resume Blueprints)
```json
{
  "userId": "USER_ID_TOKEN",
  "title": "My Software Engineer Resume",
  "templateId": "modern-minimal",
  "resumeData": {
    "personalInfo": {
      "name": "Alex Mercer",
      "email": "alex.mercer@university.edu",
      "phone": "+1 (555) 789-2345",
      "linkedin": "linkedin.com/in/alex-mercer",
      "github": "github.com/alex-mercer",
      "portfolio": "alexmercer.dev"
    },
    "summary": "Results-driven undergraduate...",
    "experience": [],
    "education": [],
    "skills": ["React", "TypeScript"],
    "projects": [],
    "certifications": [],
    "languages": []
  },
  "createdAt": "TIMESTAMP",
  "updatedAt": "TIMESTAMP"
}
```

---

## 🛡️ Zero-Trust Security Hardening (Eight Pillars)

Our database is locked down inside `firestore.rules` under strict verification guidelines:
1.  **Strict Size constraints** are applied to every string parameter (`.size() <= 128` etc.) to mitigate resource-exhaustion cost attacks.
2.  **ID Characters validation** (`[a-zA-Z0-9_\-]+$`) rejects character poisoning or injection attacks.
3.  **Timestamp Immersions** verify all edits directly against the authentic server clock `request.time`.
4.  **Immutability protections** enforce that `createdAt` and `userId` fields cannot be overwritten post-inception.
5.  **List boundaries** enforce that query-scraping is blocked on the listing level by checking security parameters in-place.

---

## 🏃‍♂️ How to Run Locally

1.  Open the workspace structure in any terminal.
2.  Execute `npm install` to install dependencies.
3.  Execute `npm run dev` to start the local Vite development instance.
4.  Optionally use `npm run build` to compile the bundles.
