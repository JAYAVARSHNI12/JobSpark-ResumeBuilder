/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from "react";
import { ResumeData } from "../types";
import { AlertCircle, CheckCircle, Info, Sparkles, TrendingUp } from "lucide-react";

interface ATSScorePanelProps {
  data: ResumeData;
}

export const ATSScorePanel: React.FC<ATSScorePanelProps> = ({ data }) => {
  const analysis = useMemo(() => {
    interface AuditItem {
      title: string;
      desc: string;
      passed: boolean;
      tip: string;
    }

    const checks: Record<string, AuditItem> = {
      hasSummary: {
        title: "Professional Summary / Objective",
        desc: "A brief, impact-filled statement summarizing your qualifications.",
        passed: !!(data.summary && data.summary.trim().length >= 40),
        tip: "Add a professional summary of at least 40 characters listing your main career objectives or experience."
      },
      hasSkills: {
        title: "Industry Skills List (keywords)",
        desc: "Includes relevant hard and soft skills for search keywords.",
        passed: !!(data.skills && data.skills.length >= 6),
        tip: "Add at least 6 technical/core skills. ATS scans heavily for specific industry terms."
      },
      hasConsistentDates: {
        title: "Chronological Employment Dates",
        desc: "Clear dates formatted with month and year values.",
        passed: !!(data.experience && data.experience.length > 0 && data.experience.every(exp => exp.duration && exp.duration.trim().length > 4)),
        tip: "Ensure all work experiences list completed dates or 'Present' (e.g., 'May 2024 - Present')."
      },
      cleanFormattingNoTables: {
        title: "ATS-Safe Bullet Layout",
        desc: "Structured bullet points using standard standard characters rather than complex graphics.",
        passed: !!(data.experience.length > 0 && data.experience.every(exp => exp.bulletPoints && exp.bulletPoints.length > 0)),
        tip: "Add at least 1 detailed bullet point under each work experience describing your achievements with metric outcomes."
      },
      hasProjectsOrEducation: {
        title: "Academic Background Check",
        desc: "A clearly delineated Education section to verify degree credentials.",
        passed: !!(data.education && data.education.length > 0),
        tip: "Add your University/College details with degree and expected graduation year."
      }
    };

    let score = 0;
    const items = Object.values(checks);
    items.forEach((item) => {
      if (item.passed) score += 1;
    });

    const percent = Math.round((score / items.length) * 100);

    return {
      checks,
      score,
      maxScore: items.length,
      percent,
      items
    };
  }, [data]);

  const scoreColor = (percent: number) => {
    if (percent >= 80) return "text-emerald-600 bg-emerald-50 border-emerald-200";
    if (percent >= 50) return "text-amber-600 bg-amber-50 border-amber-200";
    return "text-rose-600 bg-rose-50 border-rose-200";
  };

  const ringColor = (percent: number) => {
    if (percent >= 80) return "stroke-emerald-500";
    if (percent >= 40) return "stroke-amber-500";
    return "stroke-rose-500";
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm font-sans">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
        <div>
          <h3 className="font-semibold text-slate-800 text-base flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-indigo-600" />
            ATS Optimizer Summary
          </h3>
          <p className="text-xs text-slate-500 font-normal">
            Real-time parsing compliance audit based on ATS algorithms.
          </p>
        </div>
        <div className="flex items-center gap-1 text-[10px] bg-slate-100 rounded px-1.5 py-0.5 text-slate-600 font-mono">
          <Sparkles className="h-3 w-3 text-indigo-500" /> Scoring Engine
        </div>
      </div>

      {/* Circle Analyzer Chart */}
      <div className="flex items-center gap-5 bg-slate-50/50 p-4 rounded-xl border border-slate-100 mb-5">
        <div className="relative h-20 w-20 flex-shrink-0">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="40"
              cy="40"
              r="34"
              className="stroke-slate-200 fill-none"
              strokeWidth="6"
            />
            <circle
              cx="40"
              cy="40"
              r="34"
              className={`fill-none transition-all duration-500 ${ringColor(analysis.percent)}`}
              strokeWidth="6"
              strokeDasharray={2 * Math.PI * 34}
              strokeDashoffset={2 * Math.PI * 34 * (1 - analysis.percent / 100)}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center font-sans">
            <span className="text-xl font-bold text-slate-800">{analysis.percent}%</span>
            <span className="text-[9px] text-slate-500 font-medium">ATS FIT</span>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-slate-800">
            {analysis.percent >= 80 ? "Superb Optimization!" : analysis.percent >= 50 ? "Almost Approved!" : "Improvements Required"}
          </h4>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Your resume complies with {analysis.score} out of {analysis.maxScore} crucial structural guidelines. Undergo the audit items below.
          </p>
        </div>
      </div>

      {/* Review items checklist */}
      <div className="space-y-4">
        <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400">Compliance Audit Checks</h5>
        
        {analysis.items.map((item, idx) => (
          <div
            key={idx}
            className={`border rounded-lg p-3 transition-colors duration-200 ${
              item.passed ? "bg-slate-50/30 border-slate-200" : "bg-rose-50/10 border-rose-100"
            }`}
          >
            <div className="flex items-start gap-2.5">
              {item.passed ? (
                <CheckCircle className="h-5 w-5 text-emerald-500 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertCircle className="h-5 w-5 text-rose-500 mt-0.5 flex-shrink-0" />
              )}
              <div className="flex-1">
                <span className={`text-xs font-semibold ${item.passed ? "text-slate-800" : "text-slate-950"}`}>
                  {item.title}
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">
                  {item.desc}
                </p>
                {!item.passed && (
                  <div className="mt-2 text-xs bg-amber-50 border border-amber-200/50 p-2 rounded text-amber-900 leading-relaxed font-normal">
                    💡 <span className="font-medium">Actionable advice:</span> {item.tip}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5 border-t border-slate-100 pt-3">
        <p className="text-[10px] text-slate-400 leading-normal flex items-start gap-1">
          <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
          ATS systems read structured single-column text files. Avoid adding unrequested decorations, tables, or floating graphics.
        </p>
      </div>
    </div>
  );
};
