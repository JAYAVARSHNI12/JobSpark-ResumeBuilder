/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Hammer, LogOut, FileText, Layout, Info, User } from "lucide-react";

export const Navbar: React.FC = () => {
  const { profile, signOutUser, isGuest } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    try {
      await signOutUser();
      navigate("/login");
    } catch (e) {
      console.error("Logout error:", e);
    }
  };

  if (!profile) return null;

  const isActive = (path: string) => location.pathname.startsWith(path);

  // Extract initials for display profile token
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .substring(0, 2)
      .toUpperCase();
  };

  return (
    <nav className="bg-slate-900 border-b border-slate-800 text-white shadow-md relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Brand */}
          <div className="flex items-center">
            <Link to="/dashboard" className="flex items-center gap-2 group">
              <div className="p-2 bg-gradient-to-tr from-amber-500 to-orange-600 rounded-lg shadow-sm group-hover:scale-105 transition-transform duration-200">
                <Hammer className="h-5 w-5 text-white" />
              </div>
              <span className="font-sans font-bold text-lg tracking-tight bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                ResumeForge
              </span>
              <span className="hidden sm:inline-block text-[10px] bg-slate-800 text-amber-500 font-mono px-1.5 py-0.5 rounded border border-amber-500/20">
                v1.0 Capstone
              </span>
            </Link>

            {/* Links Block */}
            <div className="hidden md:flex ml-10 space-x-4">
              <Link
                to="/dashboard"
                className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard")
                    ? "bg-slate-800 text-white border-b-2 border-amber-500"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <FileText className="h-4 w-4" />
                My Resumes
              </Link>
              <Link
                to="/templates"
                className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/templates")
                    ? "bg-slate-800 text-white border-b-2 border-amber-500"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Layout className="h-4 w-4" />
                Templates
              </Link>
            </div>
          </div>

          {/* User Options */}
          <div className="flex items-center gap-4">
            {isGuest && (
              <span className="hidden sm:inline-flex items-center text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full font-mono font-medium">
                Demo Guest Mode
              </span>
            )}
            
            <div className="flex items-center gap-3 bg-slate-800/60 rounded-full py-1 pl-3 pr-1 border border-slate-700/50">
              <span className="text-xs text-slate-300 font-medium hidden sm:inline max-w-[120px] truncate">
                {profile.name}
              </span>
              <div className="h-8 w-8 rounded-full bg-amber-500 flex items-center justify-center font-sans font-semibold text-xs text-slate-950 shadow-sm border border-slate-700/50 cursor-pointer hover:bg-amber-400 transition-colors">
                {getInitials(profile.name)}
              </div>
            </div>

            {/* Logout Action */}
            <button
              onClick={handleLogout}
              className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
              title="Logout Profile"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sticky Rail */}
      <div className="flex md:hidden bg-slate-950 border-t border-slate-800 justify-around py-2.5">
        <Link
          to="/dashboard"
          className={`text-xs flex flex-col items-center gap-1 ${
            isActive("/dashboard") ? "text-amber-500" : "text-slate-400"
          }`}
        >
          <FileText className="h-4 w-4" />
          Dashboard
        </Link>
        <Link
          to="/templates"
          className={`text-xs flex flex-col items-center gap-1 ${
            isActive("/templates") ? "text-amber-500" : "text-slate-400"
          }`}
        >
          <Layout className="h-4 w-4" />
          Templates
        </Link>
      </div>
    </nav>
  );
};
