/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Education as EducationType } from "../../types";
import { GraduationCap, Plus, Trash2 } from "lucide-react";

interface EducationProps {
  data: EducationType[];
  onChange: (updated: EducationType[]) => void;
}

export const Education: React.FC<EducationProps> = ({ data, onChange }) => {
  const handleAddEducation = () => {
    const newItem: EducationType = {
      id: "edu-" + Date.now(),
      degree: "",
      institution: "",
      location: "",
      year: "",
      gpa: ""
    };
    onChange([...data, newItem]);
  };

  const handleRemoveEducation = (id: string) => {
    onChange(data.filter((item) => item.id !== id));
  };

  const handleFieldChange = (id: string, field: keyof EducationType, value: string) => {
    const updated = data.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          [field]: value
        };
      }
      return item;
    });
    onChange(updated);
  };

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
            <GraduationCap className="h-4.5 w-4.5 text-amber-500" />
            Education Background
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Details of your university, degrees, and academic records.
          </p>
        </div>
        <button
          onClick={handleAddEducation}
          type="button"
          className="flex items-center gap-1 px-3 py-1.5 bg-indigo-55 border border-indigo-200 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5" />
          Add Education
        </button>
      </div>

      {data.length === 0 ? (
        <div className="border border-dashed border-slate-200 rounded-lg p-8 text-center bg-slate-50/50">
          <GraduationCap className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-600">No education entries listed.</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Click 'Add Education' above to document your academia.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {data.map((item, idx) => (
            <div
              key={item.id}
              className="border border-slate-100 rounded-xl p-4 bg-slate-50/30 hover:bg-slate-50/60 transition-colors relative group"
            >
              {/* Delete button */}
              <button
                onClick={() => handleRemoveEducation(item.id)}
                className="absolute top-4 right-4 p-1.5 bg-white rounded-lg border border-slate-200 text-slate-400 hover:text-rose-500 hover:border-rose-200 transition-all opacity-0 group-hover:opacity-100 shadow-sm cursor-pointer"
                title="Remove Education Section"
              >
                <Trash2 className="h-4 w-4" />
              </button>

              <span className="text-[10px] font-mono font-bold bg-slate-200/50 text-slate-600 px-2 py-0.5 rounded">
                Institution #{idx + 1}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                {/* Degree field */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Degree / Specialization</label>
                  <input
                    type="text"
                    value={item.degree || ""}
                    onChange={(e) => handleFieldChange(item.id, "degree", e.target.value)}
                    placeholder="e.g. B.S. in Computer Science"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Institution name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">School / University</label>
                  <input
                    type="text"
                    value={item.institution || ""}
                    onChange={(e) => handleFieldChange(item.id, "institution", e.target.value)}
                    placeholder="e.g. State Tech University"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Location Details</label>
                  <input
                    type="text"
                    value={item.location || ""}
                    onChange={(e) => handleFieldChange(item.id, "location", e.target.value)}
                    placeholder="e.g. Metro City, NY"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Year */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Year / Expected Graduation</label>
                  <input
                    type="text"
                    value={item.year || ""}
                    onChange={(e) => handleFieldChange(item.id, "year", e.target.value)}
                    placeholder="e.g. 2027 or Expected May 2027"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* GPA */}
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">GPA / Honors (Optional)</label>
                  <input
                    type="text"
                    value={item.gpa || ""}
                    onChange={(e) => handleFieldChange(item.id, "gpa", e.target.value)}
                    placeholder="e.g. 3.85 / 4.0 or Cum Laude"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
