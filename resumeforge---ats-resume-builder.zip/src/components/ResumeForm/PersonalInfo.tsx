/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { PersonalInfo as PersonalInfoType } from "../../types";
import { User, Mail, Phone, Linkedin, Github, Globe } from "lucide-react";

interface PersonalInfoProps {
  data: PersonalInfoType;
  onChange: (updated: PersonalInfoType) => void;
}

export const PersonalInfo: React.FC<PersonalInfoProps> = ({ data, onChange }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({
      ...data,
      [name]: value
    });
  };

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div>
        <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
          <User className="h-4 w-4 text-amber-500" />
          Personal Contact Information
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Enter your professional contact points. ATS scanners utilize these to identify you.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Full Name */}
        <div className="col-span-1 sm:col-span-2">
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Full Name</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <User className="h-4 w-4" />
            </span>
            <input
              type="text"
              name="name"
              value={data.name || ""}
              onChange={handleChange}
              placeholder="e.g. Alex Mercer"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>

        {/* Email Address */}
        <div>
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Email Address</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Mail className="h-4 w-4" />
            </span>
            <input
              type="email"
              name="email"
              value={data.email || ""}
              onChange={handleChange}
              placeholder="alex@university.edu"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>

        {/* Telephone Number */}
        <div>
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Contact Phone</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Phone className="h-4 w-4" />
            </span>
            <input
              type="text"
              name="phone"
              value={data.phone || ""}
              onChange={handleChange}
              placeholder="+1 (555) 0192"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>

        {/* LinkedIn handle */}
        <div>
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">LinkedIn Profile</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Linkedin className="h-4 w-4" />
            </span>
            <input
              type="text"
              name="linkedin"
              value={data.linkedin || ""}
              onChange={handleChange}
              placeholder="linkedin.com/in/username"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>

        {/* GitHub link */}
        <div>
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">GitHub Profile</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Github className="h-4 w-4" />
            </span>
            <input
              type="text"
              name="github"
              value={data.github || ""}
              onChange={handleChange}
              placeholder="github.com/username"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>

        {/* Portfolio link */}
        <div className="col-span-1 sm:col-span-2">
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Portfolio URL</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Globe className="h-4 w-4" />
            </span>
            <input
              type="text"
              name="portfolio"
              value={data.portfolio || ""}
              onChange={handleChange}
              placeholder="e.g. portfolio.yourdomain.com"
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-850"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
