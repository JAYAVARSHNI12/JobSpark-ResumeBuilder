/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Project as ProjectType } from "../../types";
import { FolderGit, Plus, Trash2 } from "lucide-react";

interface ProjectsProps {
  data: ProjectType[];
  onChange: (updated: ProjectType[]) => void;
}

export const Projects: React.FC<ProjectsProps> = ({ data, onChange }) => {
  const handleAddProject = () => {
    const newItem: ProjectType = {
      id: "proj-" + Date.now(),
      name: "",
      techStack: "",
      description: "",
      githubLink: ""
    };
    onChange([...data, newItem]);
  };

  const handleRemoveProject = (id: string) => {
    onChange(data.filter((item) => item.id !== id));
  };

  const handleFieldChange = (id: string, field: keyof ProjectType, value: string) => {
    const updated = data.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          [field]: value
        };
      }
      return item;
    });
    onChange(updated);
  };

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
            <FolderGit className="h-4.5 w-4.5 text-amber-500" />
            Projects Profile
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Details of custom engineering builds, showcasing practical application of skills.
          </p>
        </div>
        <button
          onClick={handleAddProject}
          type="button"
          className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5" />
          Add Project
        </button>
      </div>

      {data.length === 0 ? (
        <div className="border border-dashed border-slate-200 rounded-lg p-8 text-center bg-slate-50/50">
          <FolderGit className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-600">No project listings yet.</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Click 'Add Project' above to document your accomplishments.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {data.map((item, idx) => (
            <div
              key={item.id}
              className="border border-slate-100 rounded-xl p-4 bg-slate-50/30 hover:bg-slate-50/60 transition-colors relative group"
            >
              {/* Delete button */}
              <button
                onClick={() => handleRemoveProject(item.id)}
                className="absolute top-4 right-4 p-1.5 bg-white rounded-lg border border-slate-200 text-slate-400 hover:text-rose-500 hover:border-rose-200 transition-all opacity-0 group-hover:opacity-100 shadow-sm cursor-pointer"
                title="Remove Project Segment"
              >
                <Trash2 className="h-4 w-4" />
              </button>

              <span className="text-[10px] font-mono font-bold bg-slate-200/50 text-slate-600 px-2 py-0.5 rounded">
                Project #{idx + 1}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                {/* Project Name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Project Identifier Name</label>
                  <input
                    type="text"
                    value={item.name || ""}
                    onChange={(e) => handleFieldChange(item.id, "name", e.target.value)}
                    placeholder="e.g. ResumeForge Builder"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Tech Stack */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tech Stack Utilized</label>
                  <input
                    type="text"
                    value={item.techStack || ""}
                    onChange={(e) => handleFieldChange(item.id, "techStack", e.target.value)}
                    placeholder="e.g. React, TypeScript, Node"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* GitHub link */}
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">GitHub / Code URL (Optional)</label>
                  <input
                    type="text"
                    value={item.githubLink || ""}
                    onChange={(e) => handleFieldChange(item.id, "githubLink", e.target.value)}
                    placeholder="e.g. github.com/username/project"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Description */}
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Project Contributions/Summary</label>
                  <textarea
                    rows={2}
                    value={item.description || ""}
                    onChange={(e) => handleFieldChange(item.id, "description", e.target.value)}
                    placeholder="e.g. Implemented full-stack resume architect app providing clean structural templates..."
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500/20"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
