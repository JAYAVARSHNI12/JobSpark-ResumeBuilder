/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Hammer, Plus, X } from "lucide-react";

interface SkillsProps {
  data: string[];
  onChange: (updated: string[]) => void;
}

const COMMON_CS_SUGGESTIONS = [
  "TypeScript", "JavaScript", "React", "Node.js", "Express", "Python", 
  "HTML5 & CSS3", "Tailwind CSS", "SQL", "PostgreSQL", "MongoDB", "Firebase", 
  "Git & GitHub", "RESTful APIs", "Data Structures", "Docker", "AWS", "Agile"
];

export const Skills: React.FC<SkillsProps> = ({ data, onChange }) => {
  const [inputVal, setInputVal] = useState<string>("");

  const handleAddSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (trimmed && !data.includes(trimmed)) {
      onChange([...data, trimmed]);
      setInputVal("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddSkill(inputVal);
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    onChange(data.filter((s) => s !== skillToRemove));
  };

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div>
        <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
          <Hammer className="h-4 w-4 text-amber-500" />
          Technical & Soft Skills (Keywords)
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          ATS keyword matching filters candidate suitability based on these keys. Press Enter to submit a tag.
        </p>
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a skill e.g. Docker, Python..."
          className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-850"
        />
        <button
          onClick={() => handleAddSkill(inputVal)}
          type="button"
          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-lg transition-colors cursor-pointer"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      {/* Tags Container */}
      {data.length > 0 ? (
        <div className="flex flex-wrap gap-2 py-1.5">
          {data.map((skill) => (
            <div
              key={skill}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-full px-3 py-1 text-xs font-semibold select-none transition-colors"
            >
              <span>{skill}</span>
              <button
                onClick={() => handleRemoveSkill(skill)}
                type="button"
                className="text-slate-400 hover:text-slate-650 font-bold p-0.5"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-slate-400 italic">No skills added yet. Include some to configure keyword scanners.</p>
      )}

      {/* Suggested lists */}
      <div className="border-t border-slate-100 pt-3">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Popular CS Suggestions</span>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {COMMON_CS_SUGGESTIONS.map((skill) => {
            const isSelected = data.includes(skill);
            return (
              <button
                key={skill}
                onClick={() => handleAddSkill(skill)}
                type="button"
                disabled={isSelected}
                className={`text-[10px] h-6 px-2 rounded-md font-medium border select-none transition-all cursor-pointer ${
                  isSelected
                    ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed"
                    : "bg-indigo-50/50 hover:bg-indigo-50 border-indigo-100 text-indigo-700"
                }`}
              >
                {isSelected ? "✓ " : ""}
                {skill}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
