/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { WorkExperience as WorkExperienceType } from "../../types";
import { Briefcase, Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react";

interface WorkExperienceProps {
  data: WorkExperienceType[];
  onChange: (updated: WorkExperienceType[]) => void;
}

export const WorkExperience: React.FC<WorkExperienceProps> = ({ data, onChange }) => {
  const handleAddExperience = () => {
    const newItem: WorkExperienceType = {
      id: "exp-" + Date.now(),
      title: "",
      company: "",
      location: "",
      duration: "",
      bulletPoints: [""]
    };
    onChange([...data, newItem]);
  };

  const handleRemoveExperience = (id: string) => {
    onChange(data.filter((item) => item.id !== id));
  };

  const handleFieldChange = (id: string, field: keyof WorkExperienceType, value: any) => {
    const updated = data.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          [field]: value
        };
      }
      return item;
    });
    onChange(updated);
  };

  // Bullet points helpers
  const handleAddBullet = (expId: string) => {
    const updated = data.map((item) => {
      if (item.id === expId) {
        return {
          ...item,
          bulletPoints: [...item.bulletPoints, ""]
        };
      }
      return item;
    });
    onChange(updated);
  };

  const handleRemoveBullet = (expId: string, index: number) => {
    const updated = data.map((item) => {
      if (item.id === expId) {
        const filteredBullets = item.bulletPoints.filter((_, i) => i !== index);
        return {
          ...item,
          bulletPoints: filteredBullets.length > 0 ? filteredBullets : [""]
        };
      }
      return item;
    });
    onChange(updated);
  };

  const handleBulletChange = (expId: string, index: number, value: string) => {
    const updated = data.map((item) => {
      if (item.id === expId) {
        const newBullets = [...item.bulletPoints];
        newBullets[index] = value;
        return {
          ...item,
          bulletPoints: newBullets
        };
      }
      return item;
    });
    onChange(updated);
  };

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
            <Briefcase className="h-4 w-4 text-amber-500" />
            Professional Work Experience
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Delineate professional roles. List metric achievements in your bullet points.
          </p>
        </div>
        <button
          onClick={handleAddExperience}
          type="button"
          className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5" />
          Add Job
        </button>
      </div>

      {data.length === 0 ? (
        <div className="border border-dashed border-slate-200 rounded-lg p-8 text-center bg-slate-50/50">
          <Briefcase className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-600">No work experiences listed yet.</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Click 'Add Job' above to start detailing your history.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {data.map((item, idx) => (
            <div
              key={item.id}
              className="border border-slate-100 rounded-xl p-4 bg-slate-50/30 hover:bg-slate-50/60 transition-colors relative group"
            >
              {/* Trash/delete job option */}
              <button
                onClick={() => handleRemoveExperience(item.id)}
                className="absolute top-4 right-4 p-1.5 bg-white rounded-lg border border-slate-200 text-slate-400 hover:text-rose-500 hover:border-rose-200 transition-all opacity-0 group-hover:opacity-100 shadow-sm cursor-pointer"
                title="Remove job experience"
              >
                <Trash2 className="h-4 w-4" />
              </button>

              <span className="text-[10px] font-mono font-bold bg-slate-200/50 text-slate-600 px-2 py-0.5 rounded">
                Job #{idx + 1}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                {/* Job Title */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Role / Job Title</label>
                  <input
                    type="text"
                    value={item.title || ""}
                    onChange={(e) => handleFieldChange(item.id, "title", e.target.value)}
                    placeholder="e.g. Software Development Intern"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Company name */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Company / Institution</label>
                  <input
                    type="text"
                    value={item.company || ""}
                    onChange={(e) => handleFieldChange(item.id, "company", e.target.value)}
                    placeholder="e.g. InnovateTech Solutions"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Location Details</label>
                  <input
                    type="text"
                    value={item.location || ""}
                    onChange={(e) => handleFieldChange(item.id, "location", e.target.value)}
                    placeholder="e.g. San Jose, CA (Hybrid)"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>

                {/* Duration */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Duration Range</label>
                  <input
                    type="text"
                    value={item.duration || ""}
                    onChange={(e) => handleFieldChange(item.id, "duration", e.target.value)}
                    placeholder="e.g. May 2025 - August 2025"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 bg-white"
                  />
                </div>
              </div>

              {/* Bullet points mapping */}
              <div className="mt-4 border-t border-slate-100 pt-3">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase">Achievement Bullets</label>
                  <button
                    onClick={() => handleAddBullet(item.id)}
                    type="button"
                    className="flex items-center gap-0.5 text-[10px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                  >
                    <Plus className="h-3 w-3" /> Add Bullet
                  </button>
                </div>

                <div className="space-y-2">
                  {item.bulletPoints.map((bullet, bIdx) => (
                    <div key={bIdx} className="flex gap-2">
                      <span className="text-xs text-slate-400 mt-2 font-mono">#{bIdx + 1}</span>
                      <input
                        type="text"
                        value={bullet || ""}
                        onChange={(e) => handleBulletChange(item.id, bIdx, e.target.value)}
                        placeholder="e.g. Leveraged TypeScript to refactor obsolete controllers, slashing bugs by 15%."
                        className="flex-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500/20"
                      />
                      <button
                        onClick={() => handleRemoveBullet(item.id, bIdx)}
                        type="button"
                        className="p-1.5 text-slate-400 hover:text-rose-500 rounded border border-slate-200 bg-white"
                        title="Delete this bullet"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
