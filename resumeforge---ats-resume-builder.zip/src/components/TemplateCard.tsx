/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Check } from "lucide-react";

interface TemplateCardProps {
  id: string;
  name: string;
  description: string;
  targetIndustry: string;
  isSelected: boolean;
  onSelect: () => void;
}

export const TemplateCard: React.FC<TemplateCardProps> = ({
  id,
  name,
  description,
  targetIndustry,
  isSelected,
  onSelect
}) => {
  return (
    <div
      onClick={onSelect}
      className={`relative rounded-xl overflow-hidden border cursor-pointer transition-all duration-300 group hover:shadow-lg ${
        isSelected
          ? "border-amber-500 ring-2 ring-amber-500/30 bg-slate-900/40"
          : "border-slate-200 hover:border-slate-300 bg-white"
      }`}
    >
      {/* Mini Blueprint Preview */}
      <div className={`h-40 p-4 border-b flex flex-col gap-2 relative overflow-hidden ${
        isSelected ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
      }`}>
        {/* Template Layout Sandbox Mockup */}
        {id === "classic" && (
          <div className="flex flex-col gap-1.5 h-full opacity-60">
            <div className="w-1/3 h-2 bg-slate-400 mx-auto rounded"></div>
            <div className="w-2/3 h-1 bg-slate-300 mx-auto rounded"></div>
            <div className="w-full border-t border-slate-300 my-1"></div>
            <div className="w-1/4 h-2 bg-slate-400 rounded"></div>
            <div className="flex gap-2 w-full mt-1">
              <div className="w-1/5 h-1 px-1 bg-slate-300 rounded"></div>
              <div className="w-4/5 flex flex-col gap-1">
                <div className="w-full h-1 bg-slate-300 rounded"></div>
                <div className="w-5/6 h-1 bg-slate-300 rounded"></div>
              </div>
            </div>
          </div>
        )}

        {id === "modern-minimal" && (
          <div className="flex gap-3 h-full opacity-60">
            {/* Sidebar Accent col */}
            <div className="w-1/4 bg-slate-300/40 h-full p-1.5 flex flex-col gap-2 rounded-sm">
              <div className="w-full h-2 bg-slate-400 rounded-sm"></div>
              <div className="w-4/5 h-1 bg-slate-300 rounded"></div>
              <div className="w-5/6 h-1 bg-slate-300 rounded"></div>
            </div>
            {/* Main content body */}
            <div className="w-3/4 flex flex-col gap-2">
              <div className="w-1/2 h-2.5 bg-slate-500 rounded"></div>
              <div className="w-full h-1.5 bg-slate-300 rounded"></div>
              <div className="w-5/6 h-1.5 bg-slate-300 rounded"></div>
              <div className="w-1/3 h-2.5 bg-slate-400 rounded mt-2"></div>
              <div className="w-full h-1.5 bg-slate-300 rounded"></div>
            </div>
          </div>
        )}

        {id === "executive" && (
          <div className="flex flex-col gap-2 h-full opacity-60">
            <div className="flex justify-between items-center bg-slate-200 p-1.5 rounded-sm">
              <div className="w-1/3 h-2.5 bg-slate-500 rounded"></div>
              <div className="w-1/4 h-1.5 bg-slate-400 rounded"></div>
            </div>
            <div className="w-1/4 h-2 bg-slate-400 rounded"></div>
            <div className="w-full border-b border-dashed border-slate-400 my-0.5"></div>
            <div className="w-full h-1.5 bg-slate-300 rounded"></div>
            <div className="w-11/12 h-1.5 bg-slate-300 rounded"></div>
          </div>
        )}

        {id === "student-fresh" && (
          <div className="flex flex-col gap-2 h-full opacity-60">
            <div className="w-1/2 h-3 bg-slate-500 rounded"></div>
            <div className="w-3/4 h-1.5 bg-slate-300 rounded"></div>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <div className="border border-slate-200 p-1.5 rounded flex flex-col gap-1">
                <div className="w-1/2 h-1.5 bg-slate-400 rounded"></div>
                <div className="w-full h-1 bg-slate-300 rounded"></div>
              </div>
              <div className="border border-slate-200 p-1.5 rounded flex flex-col gap-1">
                <div className="w-1/2 h-1.5 bg-slate-400 rounded"></div>
                <div className="w-full h-1 bg-slate-300 rounded"></div>
              </div>
            </div>
          </div>
        )}

        {/* Selected tick badge */}
        {isSelected && (
          <div className="absolute top-2 right-2 bg-amber-500 text-slate-950 p-1 rounded-full shadow-md animate-fade-in">
            <Check className="h-4 w-4 stroke-[3px]" />
          </div>
        )}
      </div>

      {/* Details Footer */}
      <div className="p-4 flex flex-col justify-between h-32 select-none">
        <div>
          <h3 className={`font-sans font-semibold text-sm ${isSelected ? "text-amber-500" : "text-slate-800"}`}>
            {name}
          </h3>
          <p className="text-xs text-slate-500 mt-1 line-clamp-2">
            {description}
          </p>
        </div>
        <div className="text-[10px] w-fit font-mono font-medium px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-600">
          Target: {targetIndustry}
        </div>
      </div>
    </div>
  );
};
