/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useEffect, useState } from "react";
import { User as FirebaseUser, onAuthStateChanged } from "firebase/auth";
import { auth, db } from "../firebase/firebaseConfig";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { signUpUser, loginUser, loginWithGoogle, logoutUser } from "../firebase/auth";

export interface UserProfileData {
  uid: string;
  name: string;
  email: string;
  createdAt: string;
}

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfileData | null;
  loading: boolean;
  isGuest: boolean;
  login: (email: string, password: string) => Promise<any>;
  signUp: (email: string, password: string, name: string) => Promise<any>;
  loginGoogle: () => Promise<any>;
  signOutUser: () => Promise<void>;
  enableGuestMode: (name?: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isGuest, setIsGuest] = useState<boolean>(() => {
    // Check if the user was in local guest mode before page reload
    return localStorage.getItem("rf_is_guest") === "true";
  });

  // Load guest profile if stored
  useEffect(() => {
    if (isGuest) {
      const guestName = localStorage.getItem("rf_guest_name") || "Guest Scholar";
      const guestEmail = localStorage.getItem("rf_guest_email") || "guest@resumeforge.edu";
      setProfile({
        uid: "guest-uid-123",
        name: guestName,
        email: guestEmail,
        createdAt: new Date().toISOString()
      });
      setLoading(false);
    }
  }, [isGuest]);

  useEffect(() => {
    if (isGuest) return;

    // Listen to actual Firebase auth states
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        try {
          // Attempt to retrieve the Firestore Profile document
          const docRef = doc(db, "users", currentUser.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            const data = docSnap.data();
            setProfile({
              uid: currentUser.uid,
              name: data.name || "Scholar User",
              email: data.email || currentUser.email || "",
              createdAt: data.createdAt ? new Date(data.createdAt.seconds * 1000).toISOString() : new Date().toISOString()
            });
          } else {
            // Profile document fallbacks
            setProfile({
              uid: currentUser.uid,
              name: currentUser.displayName || "Scholar User",
              email: currentUser.email || "",
              createdAt: new Date().toISOString()
            });
          }
        } catch (error) {
          console.warn("Could not load Firestore profile, falling back to simple Auth state:", error);
          setProfile({
            uid: currentUser.uid,
            name: currentUser.displayName || "Scholar User",
            email: currentUser.email || "",
            createdAt: new Date().toISOString()
          });
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isGuest]);

  /**
   * Action triggers
   */
  const login = async (email: string, password: string) => {
    setLoading(true);
    setIsGuest(false);
    localStorage.removeItem("rf_is_guest");
    try {
      const res = await loginUser(email, password);
      return res;
    } catch (e) {
      setLoading(false);
      throw e;
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    setLoading(true);
    setIsGuest(false);
    localStorage.removeItem("rf_is_guest");
    try {
      const res = await signUpUser(email, password, name);
      return res;
    } catch (e) {
      setLoading(false);
      throw e;
    }
  };

  const loginGoogle = async () => {
    setLoading(true);
    setIsGuest(false);
    localStorage.removeItem("rf_is_guest");
    try {
      const res = await loginWithGoogle();
      return res;
    } catch (e) {
      setLoading(false);
      throw e;
    }
  };

  const signOutUser = async () => {
    setLoading(true);
    if (isGuest) {
      setIsGuest(false);
      setProfile(null);
      localStorage.removeItem("rf_is_guest");
      localStorage.removeItem("rf_guest_name");
      localStorage.removeItem("rf_guest_email");
      setLoading(false);
    } else {
      try {
        await logoutUser();
        setUser(null);
        setProfile(null);
        setLoading(false);
      } catch (e) {
        setLoading(false);
        throw e;
      }
    }
  };

  /**
   * Guest Access activation helper (super elegant for student submissions!)
   */
  const enableGuestMode = (name: string = "Guest Creator") => {
    setLoading(true);
    setIsGuest(true);
    localStorage.setItem("rf_is_guest", "true");
    localStorage.setItem("rf_guest_name", name);
    localStorage.setItem("rf_guest_email", "guest@resumeforge.edu");
    setUser(null);
    setProfile({
      uid: "guest-uid-123",
      name: name,
      email: "guest@resumeforge.edu",
      createdAt: new Date().toISOString()
    });
    setLoading(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        isGuest,
        login,
        signUp,
        loginGoogle,
        signOutUser,
        enableGuestMode
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
