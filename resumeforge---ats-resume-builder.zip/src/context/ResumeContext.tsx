/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from "react";
import { useAuth } from "./AuthContext";
import {
  saveResume as saveFirestoreResume,
  getResume as getFirestoreResume,
  getUserResumes as getFirestoreUserResumes,
  deleteResume as deleteFirestoreResume,
  ResumeDocument as FirestoreResumeDocument
} from "../firebase/firestore";
import { ResumeData, INITIAL_RESUME_DATA, SAMPLE_RESUME_DATA } from "../types";

export interface Resume {
  id: string;
  userId: string;
  title: string;
  templateId: string;
  resumeData: ResumeData;
  createdAt: string;
  updatedAt: string;
}

interface ResumeContextType {
  resumes: Resume[];
  loadingResumes: boolean;
  fetchResumes: () => Promise<void>;
  createResume: (title: string, templateId: string, initialData?: ResumeData) => Promise<string>;
  updateResume: (id: string, title: string, templateId: string, resumeData: ResumeData) => Promise<void>;
  deleteResumeById: (id: string) => Promise<void>;
  getResumeById: (id: string) => Promise<Resume | null>;
  duplicateResume: (id: string) => Promise<string>;
  updateResumeTitleInline: (id: string, newTitle: string) => Promise<void>;
}

const ResumeContext = createContext<ResumeContextType | undefined>(undefined);

// Simple ID Generator helper for guest resumes
const generateId = () => "rf-" + Math.random().toString(36).substring(2, 15);

export const ResumeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { profile, isGuest } = useAuth();
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [loadingResumes, setLoadingResumes] = useState<boolean>(false);

  // Sync / fetch resumes whenever auth details change
  useEffect(() => {
    if (profile) {
      fetchResumes();
    } else {
      setResumes([]);
    }
  }, [profile, isGuest]);

  const fetchResumes = async () => {
    if (!profile) return;
    setLoadingResumes(true);
    
    try {
      if (isGuest) {
        // Load Guest resumes from localStorage
        const localKey = `rf_guest_resumes_${profile.uid}`;
        const localStr = localStorage.getItem(localKey);
        let items: Resume[] = [];
        
        if (localStr) {
          items = JSON.parse(localStr);
        } else {
          // Add a welcoming highbrow sample Resume for free exploration on first load!
          const sampleId = "rf-sample-academic";
          const sampleResume: Resume = {
            id: sampleId,
            userId: profile.uid,
            title: "Scholar Developer Sample Resume",
            templateId: "modern-minimal",
            resumeData: SAMPLE_RESUME_DATA,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          items = [sampleResume];
          localStorage.setItem(localKey, JSON.stringify(items));
        }
        setResumes(items);
      } else {
        // Fetch from Firestore
        const dbItems = await getFirestoreUserResumes(profile.uid);
        // Translate Firestore Resume format to our local Resume format
        const formatted: Resume[] = dbItems.map((doc: any) => ({
          id: doc.id,
          userId: doc.userId,
          title: doc.title,
          templateId: doc.templateId,
          resumeData: doc.resumeData,
          createdAt: typeof doc.createdAt?.toDate === "function" 
            ? doc.createdAt.toDate().toISOString() 
            : new Date(doc.createdAt).toISOString(),
          updatedAt: typeof doc.updatedAt?.toDate === "function" 
            ? doc.updatedAt.toDate().toISOString() 
            : new Date(doc.updatedAt).toISOString()
        }));
        setResumes(formatted);
      }
    } catch (e) {
      console.error("Error fetching resumes:", e);
    } finally {
      setLoadingResumes(false);
    }
  };

  const createResume = async (
    title: string,
    templateId: string,
    initialData: ResumeData = INITIAL_RESUME_DATA
  ): Promise<string> => {
    if (!profile) throw new Error("Unauthenticated user context.");
    const newId = generateId();
    const nowStr = new Date().toISOString();
    
    const newDoc: Resume = {
      id: newId,
      userId: profile.uid,
      title: title || "New Resume Draft",
      templateId: templateId || "classic",
      resumeData: initialData,
      createdAt: nowStr,
      updatedAt: nowStr
    };

    if (isGuest) {
      const localKey = `rf_guest_resumes_${profile.uid}`;
      const existing = [...resumes, newDoc];
      localStorage.setItem(localKey, JSON.stringify(existing));
      setResumes(existing);
    } else {
      await saveFirestoreResume(
        profile.uid,
        newId,
        newDoc.title,
        newDoc.templateId,
        newDoc.resumeData,
        true
      );
      // Refresh user's lists
      await fetchResumes();
    }
    return newId;
  };

  const updateResume = async (
    id: string,
    title: string,
    templateId: string,
    resumeData: ResumeData
  ): Promise<void> => {
    if (!profile) throw new Error("Unauthenticated user context.");
    const nowStr = new Date().toISOString();

    if (isGuest) {
      const localKey = `rf_guest_resumes_${profile.uid}`;
      const updated = resumes.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            title,
            templateId,
            resumeData,
            updatedAt: nowStr
          };
        }
        return item;
      });
      localStorage.setItem(localKey, JSON.stringify(updated));
      setResumes(updated);
    } else {
      await saveFirestoreResume(
        profile.uid,
        id,
        title,
        templateId,
        resumeData,
        false
      );
      await fetchResumes();
    }
  };

  const deleteResumeById = async (id: string): Promise<void> => {
    if (!profile) throw new Error("Unauthenticated user context.");

    if (isGuest) {
      const localKey = `rf_guest_resumes_${profile.uid}`;
      const filtered = resumes.filter((item) => item.id !== id);
      localStorage.setItem(localKey, JSON.stringify(filtered));
      setResumes(filtered);
    } else {
      await deleteFirestoreResume(id);
      await fetchResumes();
    }
  };

  const getResumeById = async (id: string): Promise<Resume | null> => {
    if (!profile) throw new Error("Unauthenticated user context.");

    if (isGuest) {
      const match = resumes.find((item) => item.id === id);
      return match || null;
    } else {
      const doc = await getFirestoreResume(id);
      if (doc) {
        return {
          id: doc.id || "",
          userId: doc.userId,
          title: doc.title,
          templateId: doc.templateId,
          resumeData: doc.resumeData as ResumeData,
          createdAt: typeof doc.createdAt?.toDate === "function" 
            ? doc.createdAt.toDate().toISOString() 
            : new Date(doc.createdAt).toISOString(),
          updatedAt: typeof doc.updatedAt?.toDate === "function" 
            ? doc.updatedAt.toDate().toISOString() 
            : new Date(doc.updatedAt).toISOString()
        };
      }
      return null;
    }
  };

  const duplicateResume = async (id: string): Promise<string> => {
    if (!profile) throw new Error("Unauthenticated user context.");
    
    const original = await getResumeById(id);
    if (!original) throw new Error("Original resume data not found.");

    const newId = generateId();
    const nowStr = new Date().toISOString();
    
    // Copy construction with modified title
    const copyDoc: Resume = {
      ...original,
      id: newId,
      title: `${original.title} - Copy`,
      createdAt: nowStr,
      updatedAt: nowStr
    };

    if (isGuest) {
      const localKey = `rf_guest_resumes_${profile.uid}`;
      const existing = [...resumes, copyDoc];
      localStorage.setItem(localKey, JSON.stringify(existing));
      setResumes(existing);
    } else {
      await saveFirestoreResume(
        profile.uid,
        newId,
        copyDoc.title,
        copyDoc.templateId,
        copyDoc.resumeData,
        true
      );
      await fetchResumes();
    }
    return newId;
  };

  const updateResumeTitleInline = async (id: string, newTitle: string): Promise<void> => {
    if (!profile) throw new Error("Unauthenticated user.");
    
    const resume = await getResumeById(id);
    if (!resume) throw new Error("Resume not found.");

    if (isGuest) {
      const localKey = `rf_guest_resumes_${profile.uid}`;
      const updated = resumes.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            title: newTitle || item.title,
            updatedAt: new Date().toISOString()
          };
        }
        return item;
      });
      localStorage.setItem(localKey, JSON.stringify(updated));
      setResumes(updated);
    } else {
      await saveFirestoreResume(
        profile.uid,
        id,
        newTitle || resume.title,
        resume.templateId,
        resume.resumeData,
        false
      );
      await fetchResumes();
    }
  };

  return (
    <ResumeContext.Provider
      value={{
        resumes,
        loadingResumes,
        fetchResumes,
        createResume,
        updateResume,
        deleteResumeById,
        getResumeById,
        duplicateResume,
        updateResumeTitleInline
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
};

export const useResumes = () => {
  const context = useContext(ResumeContext);
  if (context === undefined) {
    throw new Error("useResumes must be used within a ResumeProvider");
  }
  return context;
};
