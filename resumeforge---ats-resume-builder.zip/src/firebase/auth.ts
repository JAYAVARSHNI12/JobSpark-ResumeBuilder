/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  User as FirebaseUser
} from "firebase/auth";
import { auth, db } from "./firebaseConfig";
import { doc, setDoc, getDoc } from "firebase/firestore";

// Google Auth provider helper
const googleProvider = new GoogleAuthProvider();

/**
 * Interface to store user profile data in Firestore
 */
export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  createdAt: any; // Firestore Timestamp
}

/**
 * Register a new user with Email and Password, and create their profile in Firestore.
 */
export async function signUpUser(email: string, password: string, name: string): Promise<FirebaseUser> {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Create the standard user profile document in Firestore (Hardened /users Collection)
    await setDoc(doc(db, "users", user.uid), {
      uid: user.uid,
      name: name,
      email: email,
      createdAt: new Date() // Enforced request.time in security rules
    });

    return user;
  } catch (error) {
    console.error("Error in signUpUser:", error);
    throw error;
  }
}

/**
 * Login an existing user with Email and Password
 */
export async function loginUser(email: string, password: string): Promise<FirebaseUser> {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error in loginUser:", error);
    throw error;
  }
}

/**
 * Google Sign-In with Popup
 * Note: Iframe environments can block popups, so we catch this and handle it gracefully.
 */
export async function loginWithGoogle(): Promise<FirebaseUser> {
  try {
    const userCredential = await signInWithPopup(auth, googleProvider);
    const user = userCredential.user;

    // Check if user profile already exists. If not, create it.
    const userDocRef = doc(db, "users", user.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      await setDoc(userDocRef, {
        uid: user.uid,
        name: user.displayName || "Google User",
        email: user.email || "",
        createdAt: new Date()
      });
    }

    return user;
  } catch (error) {
    console.error("Error in loginWithGoogle:", error);
    throw error;
  }
}

/**
 * Logout the currently authenticated user
 */
export async function logoutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error in logoutUser:", error);
    throw error;
  }
}
