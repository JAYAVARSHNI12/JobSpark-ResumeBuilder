/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy,
  getDocFromServer,
  Timestamp
} from "firebase/firestore";
import { db, auth } from "./firebaseConfig";

// Test connection strictly as dictated by the Firebase Integration Skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.error("Please check your Firebase configuration.");
    }
  }
}
testConnection();

// Define operation types exactly as described in the Firebase Integration Skill
export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

/**
 * Handle Firestore errors by formatting them into a standard JSON string
 * as requested in the Firebase Integration Skill.
 */
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface ResumeDocument {
  id?: string;
  userId: string;
  title: string;
  templateId: string;
  resumeData: any; // Entire structured resume inputs
  createdAt: any;
  updatedAt: any;
}

/**
 * Save or Edit a Resume
 */
export async function saveResume(
  userId: string,
  resumeId: string,
  title: string,
  templateId: string,
  resumeData: any,
  isNew: boolean
): Promise<string> {
  const path = `resumes/${resumeId}`;
  try {
    const resumeDocRef = doc(db, "resumes", resumeId);
    
    const now = new Date();
    
    if (isNew) {
      const payload = {
        userId,
        title,
        templateId,
        resumeData,
        createdAt: now,
        updatedAt: now
      };
      await setDoc(resumeDocRef, payload);
    } else {
      // For updates, retrieve existing to make sure we maintain createdAt
      const existingDoc = await getDoc(resumeDocRef);
      const originalCreatedAt = existingDoc.exists() ? existingDoc.data().createdAt : now;
      
      const payload = {
        userId,
        title,
        templateId,
        resumeData,
        createdAt: originalCreatedAt,
        updatedAt: now
      };
      await setDoc(resumeDocRef, payload);
    }
    
    return resumeId;
  } catch (error) {
    return handleFirestoreError(error, isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

/**
 * Get a specific resume document by its ID
 */
export async function getResume(resumeId: string): Promise<ResumeDocument | null> {
  const path = `resumes/${resumeId}`;
  try {
    const docRef = doc(db, "resumes", resumeId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as ResumeDocument;
    }
    return null;
  } catch (error) {
    return handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Get all resumes belonging to a specific authenticated user
 */
export async function getUserResumes(userId: string): Promise<ResumeDocument[]> {
  const path = "resumes";
  try {
    const resumesRef = collection(db, "resumes");
    // Secure list query filtering by userId on server
    const q = query(resumesRef, where("userId", "==", userId));
    const querySnapshot = await getDocs(q);
    
    const list: ResumeDocument[] = [];
    querySnapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as ResumeDocument);
    });
    
    // Sort in-memory to avoid needing a complex composite index initially
    return list.sort((a, b) => {
      const bTime = b.updatedAt?.seconds || new Date(b.updatedAt).getTime();
      const aTime = a.updatedAt?.seconds || new Date(a.updatedAt).getTime();
      return bTime - aTime;
    });
  } catch (error) {
    return handleFirestoreError(error, OperationType.LIST, path);
  }
}

/**
 * Delete a resume by ID
 */
export async function deleteResume(resumeId: string): Promise<void> {
  const path = `resumes/${resumeId}`;
  try {
    const docRef = doc(db, "resumes", resumeId);
    await deleteDoc(docRef);
  } catch (error) {
    return handleFirestoreError(error, OperationType.DELETE, path);
  }
}
