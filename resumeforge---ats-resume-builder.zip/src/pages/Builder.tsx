/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useResumes } from "../context/ResumeContext";
import { useAuth } from "../context/AuthContext";
import { Navbar } from "../components/Navbar";

// Import Left Form Components
import { PersonalInfo } from "../components/ResumeForm/PersonalInfo";
import { WorkExperience } from "../components/ResumeForm/WorkExperience";
import { Education } from "../components/ResumeForm/Education";
import { Skills } from "../components/ResumeForm/Skills";
import { Projects } from "../components/ResumeForm/Projects";
import { ATSScorePanel } from "../components/ATSScorePanel";

// Import Templates
import { ClassicTemplate } from "../templates/ClassicTemplate";
import { ModernMinimalTemplate } from "../templates/ModernMinimalTemplate";
import { ExecutiveTemplate } from "../templates/ExecutiveTemplate";
import { StudentFreshTemplate } from "../templates/StudentFreshTemplate";

import { ResumeData, INITIAL_RESUME_DATA, SAMPLE_RESUME_DATA, Certification, Language } from "../types";

// Import html2pdf with compile-time bypass
// @ts-ignore
import html2pdf from "html2pdf.js";

import { 
  ArrowLeft, 
  Save, 
  Download, 
  Eye, 
  Settings, 
  Layout, 
  Award, 
  Sparkles, 
  Check, 
  Plus, 
  Trash2, 
  HelpCircle,
  FileText
} from "lucide-react";

export const Builder: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getResumeById, updateResume, createResume } = useResumes();
  const { profile } = useAuth();
  const navigate = useNavigate();

  const previewRef = useRef<HTMLDivElement>(null);

  // Core Editor State
  const [title, setTitle] = useState("My Software Engineer Resume");
  const [templateId, setTemplateId] = useState("modern-minimal");
  const [resumeData, setResumeData] = useState<ResumeData>(INITIAL_RESUME_DATA);
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // View state (mobile/desktop switcher)
  const [activeTab, setActiveTab] = useState<"editor" | "preview" | "ats">("editor");

  // Multi-Section Sub-Tabs inside editor
  const [formSubTab, setFormSubTab] = useState<"contact" | "work" | "education" | "skills" | "projects" | "additional">("contact");

  // Load existing resume if ID is present
  useEffect(() => {
    const loadResume = async () => {
      if (id) {
        setLoading(true);
        try {
          const res = await getResumeById(id);
          if (res) {
            setTitle(res.title);
            setTemplateId(res.templateId);
            setResumeData(res.resumeData);
          } else {
            console.warn("Resume ID not found, loading fresh template.");
          }
        } catch (e) {
          console.error("Error loading resume:", e);
        } finally {
          setLoading(false);
        }
      } else {
        // Init with sample data so student doesn't start with a blank screen
        setResumeData(SAMPLE_RESUME_DATA);
        setLoading(false);
      }
    };
    loadResume();
  }, [id]);

  // Sync / Save to database (real user -> Firestore, Guest -> localStorage)
  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    setSaveSuccess(false);
    try {
      if (id) {
        // Update existing
        await updateResume(id, title, templateId, resumeData);
      } else {
        // Create new
        const newId = await createResume(title, templateId, resumeData);
        navigate(`/builder/${newId}`, { replace: true });
      }
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e) {
      console.error("Failed to commit resume changes:", e);
      alert("Error committing document. Review Firestore Rules or internet connection.");
    } finally {
      setSaving(false);
    }
  };

  // Export dynamically to PDF using html2pdf.js conforming to exact margins
  const handleExportPDF = () => {
    if (!previewRef.current) return;
    
    const element = previewRef.current;
    const name = resumeData.personalInfo.name || "My";
    
    const opt = {
      margin: 0,
      filename: `${name.replace(/\s+/g, "_")}_Resume.pdf`,
      image: { type: "jpeg" as const, quality: 0.98 },
      html2canvas: { 
        scale: 2, 
        useCORS: true, 
        logging: false,
        letterRendering: true
      },
      jsPDF: { unit: "in" as const, format: "letter" as const, orientation: "portrait" as const }
    };
    
    // Trigger download
    try {
      html2pdf().from(element).set(opt).save();
    } catch (e) {
      console.error("html2pdf failed: ", e);
      // fallback print
      window.print();
    }
  };

  /**
   * Additional sections managers
   */
  // Certifications
  const handleAddCert = () => {
    const newCert: Certification = {
      id: "cert-" + Date.now(),
      name: "",
      issuer: "",
      year: ""
    };
    const certs = resumeData.certifications || [];
    setResumeData({
      ...resumeData,
      certifications: [...certs, newCert]
    });
  };

  const handleRemoveCert = (idStr: string) => {
    const certs = resumeData.certifications || [];
    setResumeData({
      ...resumeData,
      certifications: certs.filter(c => c.id !== idStr)
    });
  };

  const handleCertChange = (certId: string, field: keyof Certification, val: string) => {
    const certs = resumeData.certifications || [];
    setResumeData({
      ...resumeData,
      certifications: certs.map(c => c.id === certId ? { ...c, [field]: val } : c)
    });
  };

  // Languages
  const handleAddLang = () => {
    const newLang: Language = {
      id: "lang-" + Date.now(),
      name: "",
      proficiency: ""
    };
    const langs = resumeData.languages || [];
    setResumeData({
      ...resumeData,
      languages: [...langs, newLang]
    });
  };

  const handleRemoveLang = (idStr: string) => {
    const langs = resumeData.languages || [];
    setResumeData({
      ...resumeData,
      languages: langs.filter(l => l.id !== idStr)
    });
  };

  const handleLangChange = (langId: string, field: keyof Language, val: string) => {
    const langs = resumeData.languages || [];
    setResumeData({
      ...resumeData,
      languages: langs.map(l => l.id === langId ? { ...l, [field]: val } : l)
    });
  };

  // Render chosen template dynamically
  const renderTemplate = () => {
    switch (templateId) {
      case "classic":
        return <ClassicTemplate data={resumeData} />;
      case "modern-minimal":
        return <ModernMinimalTemplate data={resumeData} />;
      case "executive":
        return <ExecutiveTemplate data={resumeData} />;
      case "student-fresh":
        return <StudentFreshTemplate data={resumeData} />;
      default:
        return <ClassicTemplate data={resumeData} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white font-sans">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
        <p className="text-xs font-mono mt-3 text-slate-400">Loading Resume Blueprint...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      <Navbar />

      {/* Editor Commands Header Panel */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-sm px-4 py-3 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Title & Return */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Link
              to="/dashboard"
              className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
              title="Return to Dashboard"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            
            <div className="flex-1 sm:flex-none">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="My Software Engineer Resume"
                className="font-extrabold text-slate-800 text-base border-b border-transparent hover:border-slate-350 focus:border-amber-500 focus:outline-none py-0.5 max-w-[240px] truncate"
              />
              <p className="text-[10px] text-slate-400 font-medium">Inline editing of draft filename</p>
            </div>
          </div>

          {/* Action triggers */}
          <div className="flex items-center justify-end gap-2 w-full sm:w-auto">
            {/* Template Quick Switcher selection */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Layout:</span>
              <select
                value={templateId}
                onChange={(e) => setTemplateId(e.target.value)}
                className="text-xs font-bold text-slate-700 bg-transparent focus:outline-none"
              >
                <option value="classic">Classic Serif</option>
                <option value="modern-minimal">Modern Minimal</option>
                <option value="executive">Executive Bold</option>
                <option value="student-fresh">Student Fresh</option>
              </select>
            </div>

            {/* Save trigger */}
            <button
              onClick={handleSave}
              disabled={saving}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                saveSuccess
                  ? "bg-emerald-600 text-white"
                  : "bg-indigo-600 hover:bg-indigo-700 text-white text-opacity-95"
              }`}
            >
              {saveSuccess ? (
                <>
                  <Check className="h-4 w-4 stroke-[3px]" />
                  Save Complete!
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  {saving ? "Saving..." : "Save Draft"}
                </>
              )}
            </button>

            {/* Download PDF trigger */}
            <button
              onClick={handleExportPDF}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 text-xs font-extrabold rounded-xl transition-all shadow-md cursor-pointer"
            >
              <Download className="h-4 w-4" />
              Download PDF
            </button>
          </div>
        </div>
      </div>

      {/* Mobile View Switches */}
      <div className="flex md:hidden bg-slate-900 text-white justify-between px-2.5 py-2 shadow border-b border-slate-800">
        <button
          onClick={() => setActiveTab("editor")}
          className={`flex-1 text-xs py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 ${
            activeTab === "editor" ? "bg-amber-500 text-slate-950 font-black shadow" : "text-slate-405"
          }`}
        >
          <Settings className="h-3.5 w-3.5" /> Core Inputs
        </button>
        <button
          onClick={() => setActiveTab("preview")}
          className={`flex-1 text-xs py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 ${
            activeTab === "preview" ? "bg-amber-500 text-slate-950 font-black shadow" : "text-slate-300"
          }`}
        >
          <Eye className="h-3.5 w-3.5" /> PDF Preview
        </button>
        <button
          onClick={() => setActiveTab("ats")}
          className={`flex-1 text-xs py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 ${
            activeTab === "ats" ? "bg-amber-500 text-slate-950 font-black shadow" : "text-slate-300"
          }`}
        >
          <Sparkles className="h-3.5 w-3.5" /> Advisor Score
        </button>
      </div>

      {/* Main Workspace Frame */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-6 items-start h-full">

        {/* Left pane: Forms / Editor controllers */}
        <div className={`md:col-span-5 space-y-5 h-full ${activeTab === "editor" ? "block" : "hidden md:block"}`}>
          
          {/* Sub-section tabbed picker (To make it responsive and visually gorgeous under CS specs) */}
          <div className="bg-slate-900 p-1.5 rounded-xl border border-slate-800 flex flex-wrap gap-1">
            <button
              onClick={() => setFormSubTab("contact")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "contact" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Contact
            </button>
            <button
              onClick={() => setFormSubTab("work")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "work" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Work
            </button>
            <button
              onClick={() => setFormSubTab("education")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "education" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Education
            </button>
            <button
              onClick={() => setFormSubTab("skills")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "skills" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Skills
            </button>
            <button
              onClick={() => setFormSubTab("projects")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "projects" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Projects
            </button>
            <button
              onClick={() => setFormSubTab("additional")}
              className={`text-[9.5px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                formSubTab === "additional" ? "bg-amber-500 text-slate-950 font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              Extra
            </button>
          </div>

          <div className="space-y-5">
            {formSubTab === "contact" && (
              <>
                <PersonalInfo
                  data={resumeData.personalInfo}
                  onChange={(updated) => setResumeData({ ...resumeData, personalInfo: updated })}
                />
                
                {/* Professional summary form inside Contact tab */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                  <div>
                    <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
                      <FileText className="h-4 w-4 text-amber-500" />
                      Executive / Professional Summary
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Brief narrative about your objectives. Must be clear and keyword dense.
                    </p>
                  </div>
                  <textarea
                    rows={4}
                    value={resumeData.summary || ""}
                    onChange={(e) => setResumeData({ ...resumeData, summary: e.target.value })}
                    placeholder="e.g. B.S. in Computer Science with a strong background in frontend design patterns..."
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs text-slate-850 font-medium"
                  />
                </div>
              </>
            )}

            {formSubTab === "work" && (
              <WorkExperience
                data={resumeData.experience || []}
                onChange={(updated) => setResumeData({ ...resumeData, experience: updated })}
              />
            )}

            {formSubTab === "education" && (
              <Education
                data={resumeData.education || []}
                onChange={(updated) => setResumeData({ ...resumeData, education: updated })}
              />
            )}

            {formSubTab === "skills" && (
              <Skills
                data={resumeData.skills || []}
                onChange={(updated) => setResumeData({ ...resumeData, skills: updated })}
              />
            )}

            {formSubTab === "projects" && (
              <Projects
                data={resumeData.projects || []}
                onChange={(updated) => setResumeData({ ...resumeData, projects: updated })}
              />
            )}

            {formSubTab === "additional" && (
              <div className="space-y-5">
                {/* Certifications Block */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
                        <Award className="h-4 w-4 text-amber-500" />
                        Certifications (Optional)
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Add relevant certificates or cloud qualifications.
                      </p>
                    </div>
                    <button
                      onClick={handleAddCert}
                      className="flex items-center gap-0.5 text-xs text-indigo-700 font-bold hover:text-indigo-900 cursor-pointer"
                    >
                      <Plus className="h-3 w-3" /> Add Cert
                    </button>
                  </div>

                  {(!resumeData.certifications || resumeData.certifications.length === 0) ? (
                    <p className="text-xs text-slate-400 italic">No certifications added yet.</p>
                  ) : (
                    <div className="space-y-3">
                      {resumeData.certifications.map((c) => (
                        <div key={c.id} className="border border-slate-100 rounded-lg p-3 bg-slate-50/50 flex flex-col gap-2 relative group/item">
                          <button
                            onClick={() => handleRemoveCert(c.id)}
                            className="absolute right-2 top-2 p-1 text-slate-400 hover:text-rose-500 rounded border border-slate-200 bg-white opacity-0 group-hover/item:opacity-100 transition-all cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                          
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <input
                              type="text"
                              value={c.name}
                              onChange={(e) => handleCertChange(c.id, "name", e.target.value)}
                              placeholder="Cert Name e.g. AWS Associate"
                              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-850"
                            />
                            <input
                              type="text"
                              value={c.issuer}
                              onChange={(e) => handleCertChange(c.id, "issuer", e.target.value)}
                              placeholder="Issuer e.g. Amazon"
                              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-850"
                            />
                            <input
                              type="text"
                              value={c.year}
                              onChange={(e) => handleCertChange(c.id, "year", e.target.value)}
                              placeholder="Year e.g. 2025"
                              className="col-span-2 px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-850"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Languages Block */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-1.5">
                        <HelpCircle className="h-4.5 w-4.5 text-amber-500" />
                        Languages Profile
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Add foreign linguistic fluencies.
                      </p>
                    </div>
                    <button
                      onClick={handleAddLang}
                      className="flex items-center gap-0.5 text-xs text-indigo-700 font-bold hover:text-indigo-900 cursor-pointer"
                    >
                      <Plus className="h-3 w-3" /> Add Lang
                    </button>
                  </div>

                  {(!resumeData.languages || resumeData.languages.length === 0) ? (
                    <p className="text-xs text-slate-400 italic">No language profiles added yet.</p>
                  ) : (
                    <div className="space-y-3">
                      {resumeData.languages.map((l) => (
                        <div key={l.id} className="border border-slate-100 rounded-lg p-3 bg-slate-50/50 flex flex-col gap-2 relative group/lang">
                          <button
                            onClick={() => handleRemoveLang(l.id)}
                            className="absolute right-2 top-2 p-1 text-slate-400 hover:text-rose-500 rounded border border-slate-200 bg-white opacity-0 group-hover/lang:opacity-100 transition-all cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                          
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <input
                              type="text"
                              value={l.name}
                              onChange={(e) => handleLangChange(l.id, "name", e.target.value)}
                              placeholder="e.g. Spanish"
                              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-850"
                            />
                            <input
                              type="text"
                              value={l.proficiency}
                              onChange={(e) => handleLangChange(l.id, "proficiency", e.target.value)}
                              placeholder="e.g. Conversational"
                              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-850"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Embed the ATS advisor scorecard nicely as desktop-first helper tool */}
            <div className="hidden md:block">
              <ATSScorePanel data={resumeData} />
            </div>
          </div>
        </div>

        {/* Right pane: Real-time Live Rendering Canvas */}
        <div className={`md:col-span-7 space-y-5 h-full ${activeTab === "preview" ? "block" : "hidden md:block"}`}>
          <div className="bg-slate-800 p-2 border border-slate-700 rounded-2xl shadow-lg relative">
            
            {/* Live Indicator sticker */}
            <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 bg-slate-900 border border-slate-750 px-3 py-1 rounded-full text-slate-300 text-[10px] uppercase font-mono font-bold select-none shadow">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Rendering View
            </div>

            {/* Scrolling container mirroring Letter proportions */}
            <div className="max-h-[85vh] overflow-y-auto rounded-xl shadow-inner scrollbar-thin">
              <div ref={previewRef} id="resume-preview-panel" className="bg-white w-full rounded-lg">
                {renderTemplate()}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile-only ATS scorecard Tab panel view */}
        <div className={`md:col-span-5 ${activeTab === "ats" ? "block" : "hidden"}`}>
          <ATSScorePanel data={resumeData} />
        </div>

      </div>
    </div>
  );
};
