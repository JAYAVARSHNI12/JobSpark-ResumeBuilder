/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useResumes, Resume } from "../context/ResumeContext";
import { Navbar } from "../components/Navbar";
import { 
  Plus, 
  Edit, 
  Copy, 
  Trash2, 
  FileText, 
  Calendar, 
  Layers, 
  Search, 
  Check, 
  X, 
  FileSignature, 
  UserCheck 
} from "lucide-react";

export const Dashboard: React.FC = () => {
  const { profile } = useAuth();
  const { 
    resumes, 
    loadingResumes, 
    fetchResumes, 
    createResume, 
    deleteResumeById, 
    duplicateResume, 
    updateResumeTitleInline 
  } = useResumes();
  
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [editingTitleId, setEditingTitleId] = useState<string | null>(null);
  const [tempTitle, setTempTitle] = useState("");
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Re-fetch resumes on load
  useEffect(() => {
    fetchResumes();
  }, []);

  // Filter resumes by search query
  const filteredResumes = resumes.filter((r) =>
    r.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Trigger inline title editing
  const startEditingTitle = (id: string, currentTitle: string) => {
    setEditingTitleId(id);
    setTempTitle(currentTitle);
  };

  const saveInlineTitle = async (id: string) => {
    if (!tempTitle.trim()) return;
    try {
      await updateResumeTitleInline(id, tempTitle.trim());
      setEditingTitleId(null);
    } catch (e) {
      console.error("Failed to update title:", e);
    }
  };

  const handleDuplicate = async (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    setActionLoading(id);
    try {
      const newId = await duplicateResume(id);
      // Wait a tiny bit for UI feels
      setTimeout(() => {
        setActionLoading(null);
      }, 500);
    } catch (e) {
      setActionLoading(null);
      console.error("Duplicate failed:", e);
    }
  };

  const handleDelete = async (id: string, title: string, e: React.MouseEvent) => {
    e.preventDefault();
    const confirmed = window.confirm(`Are you sure you want to delete "${title}"? This is irreversible.`);
    if (confirmed) {
      try {
        await deleteResumeById(id);
      } catch (e) {
        console.error("Delete failed:", e);
      }
    }
  };

  const handleCreateNewResume = async () => {
    try {
      // Create with Classic as default
      const defaultTitle = "My Software Engineer Resume";
      const newId = await createResume(defaultTitle, "modern-minimal");
      navigate(`/builder/${newId}`);
    } catch (e) {
      console.error("Could not register new resume:", e);
    }
  };

  // Convert raw timestamp to human friendly text
  const formatDate = (isoStr: string) => {
    try {
      const date = new Date(isoStr);
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric"
      }) + " at " + date.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit"
      });
    } catch (e) {
      return "Recently";
    }
  };

  const decodeTemplateId = (id: string) => {
    switch (id) {
      case "classic": return "Classic Times";
      case "modern-minimal": return "Modern Minimal";
      case "executive": return "Executive Leadership";
      case "student-fresh": return "Student Fresh Academic";
      default: return id;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Welcome Block Section */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden mb-8">
          <div className="absolute -right-10 -bottom-10 h-40 w-40 bg-amber-500/10 rounded-full blur-2xl"></div>
          <div className="absolute -right-5 -top-5 h-20 w-20 bg-indigo-500/10 rounded-full blur-xl"></div>
          
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-wider font-semibold">
                <UserCheck className="h-4 w-4" /> Professional Workspace
              </div>
              <h2 className="text-2xl sm:text-3xl font-black mt-1">
                Welcome back, {profile?.name || "Scholar Developer"}!
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-normal max-w-2xl font-light">
                This is your ATS resume repository. Build, duplicate, and adjust multiple documents structured strictly to pass computerized corporate scanners.
              </p>
            </div>

            <button
              onClick={handleCreateNewResume}
              className="flex items-center justify-center gap-1.5 px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg transition-transform hover:-translate-y-0.5 cursor-pointer max-w-xs"
            >
              <Plus className="h-4 w-4 stroke-[3px]" />
              New Resume Blueprint
            </button>
          </div>
        </div>

        {/* Filters and Utilities bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="font-bold text-slate-800 text-lg flex items-center gap-1.5">
              <FileText className="h-5 w-5 text-indigo-600" />
              My Saved Resume blue-prints
            </h3>
            <p className="text-xs text-slate-500">
              Manage your credentials profiles. Total of {resumes.length} saved drafts.
            </p>
          </div>

          {/* Search box */}
          <div className="relative max-w-xs w-full sm:w-64">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search resumes by title..."
              className="w-full bg-white border border-slate-200 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500 pl-9 pr-3 py-2 rounded-xl text-xs font-medium text-slate-850"
            />
          </div>
        </div>

        {/* Main resumes layout deck */}
        {loadingResumes ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
            <p className="text-xs text-slate-500 mt-3 font-semibold font-mono">Syncing Firestore collections...</p>
          </div>
        ) : filteredResumes.length === 0 ? (
          <div className="bg-white border rounded-2xl p-12 text-center text-slate-400 max-w-xl mx-auto shadow-sm">
            <div className="h-14 w-14 bg-amber-50 rounded-full flex items-center justify-center text-amber-500 mx-auto mb-4 border border-amber-100">
              <FileSignature className="h-6 w-6" />
            </div>
            <h4 className="text-slate-800 font-bold text-base">
              {searchQuery ? "No search results match" : "Configure your very first Resume Forge Draft"}
            </h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              {searchQuery 
                ? "Double check your spelling keywords or clear the filter." 
                : "Create highly structured portfolios, customized for top tech ATS metrics."
              }
            </p>
            {!searchQuery && (
              <button
                onClick={handleCreateNewResume}
                className="mt-6 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm cursor-pointer"
              >
                Assemble New Resume
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResumes.map((resume) => (
              <div
                key={resume.id}
                className="bg-white border border-slate-200 hover:border-indigo-200 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-md flex flex-col group"
              >
                {/* Header detail */}
                <div className="p-5 flex-1 relative">
                  
                  {/* Template sticker */}
                  <span className="inline-flex items-center gap-1 text-[10px] bg-slate-100 border text-slate-600 font-bold px-2.5 py-0.5 rounded-full mb-3">
                    <Layers className="h-3 w-3 text-indigo-500" />
                    {decodeTemplateId(resume.templateId)}
                  </span>

                  {/* Inline title editor */}
                  {editingTitleId === resume.id ? (
                    <div className="flex gap-1.5 items-center mt-1">
                      <input
                        type="text"
                        value={tempTitle}
                        onChange={(e) => setTempTitle(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && saveInlineTitle(resume.id)}
                        className="flex-1 border border-amber-500 rounded px-2 py-1 text-sm text-slate-900 bg-amber-50/20 font-semibold focus:outline-none"
                        autoFocus
                      />
                      <button
                        onClick={() => saveInlineTitle(resume.id)}
                        className="p-1 bg-emerald-50 border border-emerald-200 rounded text-emerald-600 hover:bg-emerald-100"
                        title="Save Title"
                      >
                        <Check className="h-3.5 w-3.5 stroke-[3px]" />
                      </button>
                      <button
                        onClick={() => setEditingTitleId(null)}
                        className="p-1 bg-slate-50 border border-slate-200 rounded text-slate-505"
                        title="Cancel"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between gap-1 mt-1 group/title">
                      <Link to={`/builder/${resume.id}`} className="hover:text-indigo-600 transition-colors">
                        <h4 className="font-extrabold text-slate-800 text-sm capitalize leading-tight line-clamp-2">
                          {resume.title}
                        </h4>
                      </Link>
                      <button
                        onClick={() => startEditingTitle(resume.id, resume.title)}
                        className="opacity-0 group-hover/title:opacity-100 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded transition-all cursor-pointer"
                        title="Rename inline"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] mt-4 font-medium">
                    <Calendar className="h-3 w-3" />
                    <span>Saved: {formatDate(resume.updatedAt)}</span>
                  </div>
                </div>

                {/* Card Commands footer */}
                <div className="bg-slate-50 border-t border-slate-100 px-5 py-3.5 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => handleDuplicate(resume.id, e)}
                      disabled={actionLoading === resume.id}
                      className="p-2 border border-slate-200 text-slate-600 bg-white hover:bg-indigo-50 hover:text-indigo-750 rounded-xl transition-all cursor-pointer disabled:opacity-40 shadow-sm"
                      title="Duplicate Draft Copy"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(resume.id, resume.title, e)}
                      className="p-2 border border-slate-200 text-slate-600 bg-white hover:bg-rose-50 hover:text-rose-600 hover:border-rose-100 rounded-xl transition-all cursor-pointer shadow-sm"
                      title="Delete Resume Document"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <Link
                    to={`/builder/${resume.id}`}
                    className="flex items-center gap-1 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-colors shadow-sm"
                  >
                    <Edit className="h-3 w-3" />
                    Compile Editor
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
