/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Hammer, LogIn, Mail, Lock, ShieldAlert, Sparkles } from "lucide-react";

export const Login: React.FC = () => {
  const { login, loginGoogle, enableGuestMode } = useAuth();
  const navigate = useNavigate();
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Email login trigger
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please complete both email and password fields.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      await login(email, password);
      navigate("/dashboard");
    } catch (e: any) {
      setError(e.message || "Invalid email or password combination.");
    } finally {
      setSubmitting(false);
    }
  };

  // Google OAuth trigger
  const handleGoogleLogin = async () => {
    setError("");
    setSubmitting(true);
    try {
      await loginGoogle();
      navigate("/dashboard");
    } catch (e: any) {
      setError(e.message || "Google auth popup was blocked or cookies are restricted in iframe.");
    } finally {
      setSubmitting(false);
    }
  };

  // Demo guest bypass
  const handleGuestAccess = () => {
    enableGuestMode("CS Professor");
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white relative overflow-hidden font-sans">
      
      {/* Background visual halo filters */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      {/* Main card box container */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl relative">
        
        {/* Brand details */}
        <div className="flex flex-col items-center text-center">
          <div className="h-12 w-12 bg-gradient-to-tr from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg mb-3">
            <Hammer className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">ResumeForge</h1>
          <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-mono font-semibold">
            Capstone Student Project Build
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-550 text-red-400 p-3.5 rounded-xl text-xs flex items-start gap-2 mt-5">
            <ShieldAlert className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Email form */}
        <form onSubmit={handleEmailLogin} className="mt-6 space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Email Address</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/20 pl-10 pr-3 py-2 rounded-xl text-sm text-slate-100 transition-colors focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Password</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500">
                <Lock className="h-4 w-4" />
              </span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/20 pl-10 pr-3 py-2 rounded-xl text-sm text-slate-100 transition-colors focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold py-2.5 rounded-xl text-sm transition-colors cursor-pointer disabled:opacity-50 inline-flex items-center justify-center gap-1.5 shadow"
          >
            <LogIn className="h-4 w-4" />
            {submitting ? "Signing in..." : "Log In"}
          </button>
        </form>

        {/* Google sign in button separator */}
        <div className="relative flex py-4 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-4 text-slate-500 uppercase text-[9px] font-bold">or connect securely</span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        {/* Google sign in button */}
        <button
          onClick={handleGoogleLogin}
          type="button"
          disabled={submitting}
          className="w-full bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold py-2 rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 "
        >
          {/* Custom Google SVG */}
          <svg className="h-4 w-4" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114A5.63 5.63 0 0 1 8.35 12.89a5.63 5.63 0 0 1 5.64-5.63c2.44 0 4.542 1.54 5.383 3.664l3.87-3.003C20.655 4.3 16.745 2 12 2 6.477 2 2 6.477 2 12c0 5.522 4.477 10 10 10 5.86 0 10-3.321 10-10 0-.585-.052-1.154-.15-1.714H12.24Z"
            />
          </svg>
          Google Sign In (Popup)
        </button>

        {/* Grader / Guest bypass banner */}
        <div className="mt-6 border-t border-slate-800 pt-5 text-center">
          <div className="bg-amber-500/5 hover:bg-amber-500/10 border border-amber-500/10 hover:border-amber-500/20 px-4 py-3 rounded-xl transition-all duration-300">
            <span className="text-[10px] text-amber-400 font-bold block mb-1 flex items-center justify-center gap-1">
              <Sparkles className="h-3.5 w-3.5" /> CS GRADER / PROFESSOR SHORTCUT
            </span>
            <p className="text-[10px] text-slate-400 font-normal leading-relaxed">
              Skip Firebase database registration and test immediately using local storage database mode!
            </p>
            <button
              onClick={handleGuestAccess}
              type="button"
              className="mt-2.5 w-full bg-slate-800 hover:bg-amber-500 hover:text-slate-950 hover:shadow text-slate-200 text-xs font-bold py-1.5 rounded-lg transition-all cursor-pointer"
            >
              Demo Guest Dashboard
            </button>
          </div>
        </div>

        {/* Link to signup */}
        <p className="text-xs text-slate-400 text-center mt-6">
          Don't have a profile yet?{" "}
          <Link to="/signup" className="text-amber-500 font-semibold hover:underline">
            Register Account
          </Link>
        </p>
      </div>
    </div>
  );
};
