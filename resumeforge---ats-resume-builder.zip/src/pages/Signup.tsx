/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Hammer, User, Mail, Lock, ShieldAlert, Sparkles } from "lucide-react";

export const Signup: React.FC = () => {
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setError("Please fill out all registration fields.");
      return;
    }
    if (password.length < 6) {
      setError("Password length must be at least 6 characters.");
      return;
    }
    setSubmitting(true);
    setError("");

    try {
      await signUp(email, password, name);
      navigate("/dashboard");
    } catch (e: any) {
      setError(e.message || "Could not register account. Email may already be in use.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white relative overflow-hidden font-sans">
      
      {/* Background visual halo filters */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      {/* Card context */}
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl relative">
        <div className="flex flex-col items-center text-center">
          <div className="h-10 w-10 bg-gradient-to-tr from-amber-500 to-orange-600 rounded-lg flex items-center justify-center shadow-lg mb-2">
            <Hammer className="h-5.5 w-5.5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">Create Profile</h1>
          <p className="text-[11px] text-slate-400">
            Register to save and edit multiple resumes.
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-550 text-red-400 p-3 rounded-lg text-xs flex gap-1.5 mt-4">
            <ShieldAlert className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Action form */}
        <form onSubmit={handleSignup} className="mt-5 space-y-3.5">
          {/* Display Name */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Your Name</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                <User className="h-4 w-4" />
              </span>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Alex Mercer"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 Pl-9 pr-3 py-1.5 rounded-lg text-xs text-slate-100 transition-colors focus:outline-none"
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Email Address</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex@university.edu"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 Pl-9 pr-3 py-1.5 rounded-lg text-xs text-slate-100 transition-colors focus:outline-none"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Password</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Lock className="h-4 w-4" />
              </span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 Pl-9 pr-3 py-1.5 rounded-lg text-xs text-slate-100 transition-colors focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            {submitting ? "Creating Account..." : "Create Free Account"}
          </button>
        </form>

        <p className="text-xs text-slate-400 text-center mt-5">
          Already registered?{" "}
          <Link to="/login" className="text-amber-500 font-semibold hover:underline">
            Account Log In
          </Link>
        </p>
      </div>
    </div>
  );
};
