/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React from "react";
import { useNavigate } from "react-router-dom";
import { useResumes } from "../context/ResumeContext";
import { Navbar } from "../components/Navbar";
import { TemplateCard } from "../components/TemplateCard";
import { Layout, Sparkles, Wand2 } from "lucide-react";

const TEMPLATE_PRESETS = [
  {
    id: "classic",
    name: "Classic Academic Serif",
    description: "Traditional Times style layout with centered alignments. Best for law, banking, corporate finance, and traditional industries.",
    targetIndustry: "Finance / Consulting / Legal Roles"
  },
  {
    id: "modern-minimal",
    name: "Modern Minimal Accent Bar",
    description: "Highly contemporary asymmetric split design with subtle violet highlight sidebars. Perfect for tech, start-ups, product engineering, design and SaaS.",
    targetIndustry: "Web & Software Engineering"
  },
  {
    id: "executive",
    name: "Executive Leadership Core",
    description: "Expansive structured rules with compact metadata grids and bold header text. Optimal for senior engineers, project managers, leads, and MBAs.",
    targetIndustry: "Senior Lead & Executive Administration"
  },
  {
    id: "student-fresh",
    name: "Student Freshman Academic",
    description: "Prioritizes Education details, internships, GPA merits, and course outputs. Exceptional for fresh grads, current university students, and career changers.",
    targetIndustry: "Internships / Junior Roles"
  }
];

export const Templates: React.FC = () => {
  const { createResume } = useResumes();
  const navigate = useNavigate();

  const handleSelectTemplate = async (templateId: string, name: string) => {
    try {
      const defaultTitle = `${name} Resume Draft`;
      // Auto-trigger resume builder initialization
      const newResumeId = await createResume(defaultTitle, templateId);
      navigate(`/builder/${newResumeId}`);
    } catch (e) {
      console.error("Template shortcut builder failed:", e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Gallery Title block */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-indigo-600 font-mono text-xs uppercase tracking-wider font-semibold">
            <Sparkles className="h-4 w-4" /> Layout Architect Gallery
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
            Discover ATS-Compliant Layouts
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-3xl">
            Pick a structural coordinate. These templates are meticulously structured under human-resource parsing mandates — utilizing single grids, clear hierarchies, and clean styling that scanners love. Click any card to launch immediately!
          </p>
        </div>

        {/* Templates Deck */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TEMPLATE_PRESETS.map((preset) => (
            <div key={preset.id} className="relative group/parent">
              <TemplateCard
                id={preset.id}
                name={preset.name}
                description={preset.description}
                targetIndustry={preset.targetIndustry}
                isSelected={false}
                onSelect={() => handleSelectTemplate(preset.id, preset.name)}
              />
              
              {/* Overlay hover launch indicator */}
              <div className="absolute inset-x-4 bottom-[120px] pointer-events-none opacity-0 group-hover/parent:opacity-100 transition-all duration-300 transform translate-y-3 group-hover/parent:translate-y-0 bg-slate-900/90 text-white text-xs font-bold py-2 rounded-xl text-center shadow flex items-center justify-center gap-1.5 z-10">
                <Wand2 className="h-3.5 w-3.5 text-amber-400" />
                Initialize Blueprint
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-slate-100 border border-slate-200/50 p-6 rounded-2xl flex flex-col sm:flex-row items-center gap-5 justify-between">
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Need structure customization later?</h4>
            <p className="text-xs text-slate-550 mt-0.5">Don't worry — your data remains fully preserved in memory. You can swap templates inside the Active Workspace instantly without losing progress!</p>
          </div>
          <span className="text-xs font-bold text-slate-400 border border-slate-200 bg-white px-3 py-1 rounded-full font-mono">
            Zero-Loss Swapping Supported
          </span>
        </div>
      </div>
    </div>
  );
};
