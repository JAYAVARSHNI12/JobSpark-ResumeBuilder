/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ResumeData } from "../types";

interface TemplateProps {
  data: ResumeData;
}

export const ClassicTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, summary, experience, education, skills, projects, certifications, languages } = data;

  return (
    <div
      className="bg-white text-slate-900 p-8 sm:p-12 mx-auto font-serif leading-relaxed text-xs shadow-inner"
      style={{ fontFamily: "'Times New Roman', Georgia, Serif" }}
    >
      {/* Centered Name and Contacts */}
      <div className="text-center pb-4">
        <h1 className="text-2xl font-bold uppercase tracking-wider text-black">
          {personalInfo.name || "YOUR NAME"}
        </h1>
        <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-[10px] text-slate-700 mt-1.5 font-sans">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>• {personalInfo.phone}</span>}
          {personalInfo.linkedin && <span>• {personalInfo.linkedin}</span>}
          {personalInfo.github && <span>• {personalInfo.github}</span>}
          {personalInfo.portfolio && <span>• {personalInfo.portfolio}</span>}
        </div>
      </div>

      {/* Professional Summary */}
      {summary && (
        <div className="mb-5">
          <h2 className="text-sm font-bold uppercase tracking-wide border-b border-black pb-0.5 mb-1.5">
            Professional Summary
          </h2>
          <p className="text-justify text-[11px] leading-relaxed text-slate-800">
            {summary}
          </p>
        </div>
      )}

      {/* Work Experience */}
      {experience && experience.length > 0 && (
        <div className="mb-5">
          <h2 className="text-sm font-bold uppercase tracking-wide border-b border-black pb-0.5 mb-2">
            Professional Experience
          </h2>
          <div className="space-y-3.5">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between font-bold text-[11px] text-black">
                  <span>
                    {exp.title || "Position / Role Title"} — <span className="font-normal italic">{exp.company || "Company Name"}</span>
                  </span>
                  <span className="font-sans text-[10px]">{exp.duration || "Duration date"}</span>
                </div>
                {exp.location && (
                  <div className="text-[10px] text-slate-600 font-normal italic -mt-0.5">
                    {exp.location}
                  </div>
                )}
                {exp.bulletPoints && exp.bulletPoints.length > 0 && (
                  <ul className="list-disc pl-5 mt-1 space-y-0.5 text-[10.5px] text-slate-800 text-justify">
                    {exp.bulletPoints.map((bullet, idx) => (
                      bullet && <li key={idx}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education && education.length > 0 && (
        <div className="mb-5">
          <h2 className="text-sm font-bold uppercase tracking-wide border-b border-black pb-0.5 mb-2">
            Education
          </h2>
          <div className="space-y-2">
            {education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-start text-[11px] text-black">
                <div>
                  <span className="font-bold">{edu.institution || "School Name"}</span>
                  <span className="italic block text-[10.5px] text-slate-800">
                    {edu.degree || "Degree details"} {edu.gpa ? `— GPA: ${edu.gpa}` : ""}
                  </span>
                </div>
                <div className="text-right font-sans text-[10px]">
                  <div>{edu.year || "Year"}</div>
                  {edu.location && <div className="text-slate-500 italic text-[9px] font-serif">{edu.location}</div>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects */}
      {projects && projects.length > 0 && (
        <div className="mb-5">
          <h2 className="text-sm font-bold uppercase tracking-wide border-b border-black pb-0.5 mb-2">
            Technical Projects
          </h2>
          <div className="space-y-3">
            {projects.map((proj) => (
              <div key={proj.id}>
                <div className="flex justify-between font-bold text-[11px] text-black">
                  <span>
                    {proj.name || "Project Name"} <span className="font-sans text-[9px] font-normal text-slate-600">({proj.techStack})</span>
                  </span>
                  {proj.githubLink && (
                    <span className="font-sans text-[9px] font-normal text-indigo-700 hover:underline">
                      {proj.githubLink}
                    </span>
                  )}
                </div>
                {proj.description && (
                  <p className="text-[10.5px] text-slate-800 text-justify mt-0.5">
                    {proj.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills && skills.length > 0 && (
        <div className="mb-5">
          <h2 className="text-sm font-bold uppercase tracking-wide border-b border-black pb-0.5 mb-1.5">
            Skills & Keyword Matrices
          </h2>
          <p className="text-[10.5px] text-slate-800 leading-normal">
            <span className="font-bold">Technical Capabilities:</span> {skills.join(", ")}
          </p>
        </div>
      )}

      {/* Certifications and Languages Grid */}
      {(certifications?.length > 0 || languages?.length > 0) && (
        <div className="grid grid-cols-2 gap-4 border-t border-slate-200 pt-3">
          {certifications && certifications.length > 0 && (
            <div>
              <h3 className="font-bold text-[11px] uppercase tracking-wider text-black mb-1">Certifications</h3>
              <ul className="list-disc pl-4 text-[10px] text-slate-800 space-y-0.5">
                {certifications.map((c) => (
                  <li key={c.id}>
                    <span className="font-bold">{c.name}</span> — <span className="italic">{c.issuer}</span> ({c.year})
                  </li>
                ))}
              </ul>
            </div>
          )}

          {languages && languages.length > 0 && (
            <div>
              <h3 className="font-bold text-[11px] uppercase tracking-wider text-black mb-1">Languages</h3>
              <ul className="list-disc pl-4 text-[10px] text-slate-800 space-y-0.5">
                {languages.map((l) => (
                  <li key={l.id}>
                    <span className="font-bold">{l.name}</span> — <span className="italic">{l.proficiency}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
