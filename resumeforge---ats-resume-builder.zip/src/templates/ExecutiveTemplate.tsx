/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ResumeData } from "../types";

interface TemplateProps {
  data: ResumeData;
}

export const ExecutiveTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, summary, experience, education, skills, projects, certifications, languages } = data;

  return (
    <div
      className="bg-white text-slate-900 p-8 sm:p-12 mx-auto font-sans text-xs leading-relaxed shadow-inner max-w-4xl"
      style={{ fontFamily: "'Inter', system-ui, sans-serif" }}
    >
      {/* Header Block with colored divider */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end border-b-2 border-slate-900 pb-3 mb-5">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-slate-900 leading-none">
            {personalInfo.name || "YOUR NAME"}
          </h1>
          <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mt-1.5">
            Executive Resume Profile
          </p>
        </div>
        
        <div className="flex flex-col md:items-end text-[10px] text-slate-600 font-mono mt-3 md:mt-0 font-medium">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.linkedin && <span className="text-slate-800">{personalInfo.linkedin}</span>}
          {(personalInfo.github || personalInfo.portfolio) && (
            <span className="text-slate-800">
              {[personalInfo.github, personalInfo.portfolio].filter(Boolean).join("  |  ")}
            </span>
          )}
        </div>
      </div>

      {/* Summary statement inside a luxurious dark outline */}
      {summary && (
        <div className="mb-6 bg-slate-50 border-l-4 border-slate-700 px-4 py-3">
          <p className="text-justify text-[11px] text-slate-800 leading-relaxed font-normal">
            {summary}
          </p>
        </div>
      )}

      {/* Core Skills segment */}
      {skills && skills.length > 0 && (
        <div className="mb-6">
          <h2 className="text-[11px] font-extrabold uppercase tracking-widest text-slate-950 flex items-center gap-1.5 mb-2">
            CORE COMPETENCIES
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-x-4 gap-y-1.5 text-[10.5px] border-t border-slate-100 pt-2">
            {skills.map((skill) => (
              <div key={skill} className="flex items-center gap-2 text-slate-800">
                <span className="h-1.5 w-1.5 rounded-full bg-slate-900 flex-shrink-0"></span>
                <span className="font-semibold">{skill}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Experience Section */}
      {experience && experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-[11px] font-extrabold uppercase tracking-widest text-slate-950 mb-2">
            LEADERSHIP & PROFESSIONAL PRACTICE
          </h2>
          <div className="space-y-4 border-t border-slate-100 pt-2">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start font-bold text-[11px] text-slate-955 bg-slate-100/40 p-1 rounded-sm">
                  <span>
                    {exp.title} — <span className="font-normal italic">{exp.company}</span>
                  </span>
                  <span className="font-mono text-[9px] text-slate-500 font-bold uppercase">{exp.duration}</span>
                </div>
                {exp.location && (
                  <div className="text-[10px] text-slate-550 italic font-medium mt-0.5 px-1">
                    {exp.location}
                  </div>
                )}
                {exp.bulletPoints && exp.bulletPoints.length > 0 && (
                  <ul className="list-disc pl-5 mt-1.5 space-y-1 text-[10.5px] text-slate-700 text-justify font-normal leading-relaxed">
                    {exp.bulletPoints.map((bullet, idx) => (
                      bullet && <li key={idx}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects */}
      {projects && projects.length > 0 && (
        <div className="mb-6">
          <h2 className="text-[11px] font-extrabold uppercase tracking-widest text-slate-950 mb-2">
            KEY TECHNICAL ENDEAVOURS
          </h2>
          <div className="space-y-3.5 border-t border-slate-100 pt-2">
            {projects.map((proj) => (
              <div key={proj.id}>
                <div className="flex justify-between font-bold text-[11px] text-slate-900">
                  <span>
                    {proj.name} <span className="font-mono text-[9px] text-slate-500 font-semibold uppercase">({proj.techStack})</span>
                  </span>
                  {proj.githubLink && (
                    <span className="text-[9.5px] font-normal text-indigo-700 hover:underline">
                      {proj.githubLink}
                    </span>
                  )}
                </div>
                {proj.description && (
                  <p className="text-[10.5px] text-slate-700 text-justify mt-0.5">
                    {proj.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Academic Credentials */}
      {education && education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-[11px] font-extrabold uppercase tracking-widest text-slate-950 mb-2">
            ACADEMIC PROFILE
          </h2>
          <div className="space-y-3 border-t border-slate-100 pt-2">
            {education.map((edu) => (
              <div key={edu.id} className="flex justify-between text-[11px]">
                <div>
                  <span className="font-extrabold text-slate-900 block">{edu.institution}</span>
                  <span className="text-slate-800 text-[10.5px] italic font-medium block">
                    {edu.degree} {edu.gpa ? ` | Cumulative GPA: ${edu.gpa}` : ""}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-[9px] text-slate-500 font-bold block">{edu.year}</span>
                  {edu.location && <span className="text-[9.5px] text-slate-400 block italic">{edu.location}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Certifications and Languages Grid style */}
      {(certifications?.length > 0 || languages?.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-950/20 pt-3.5">
          {certifications && certifications.length > 0 && (
            <div>
              <h3 className="font-extrabold text-[10.5px] uppercase tracking-wider text-slate-950 mb-1.5">SPECIALIST CERTIFICATIONS</h3>
              <ul className="list-disc pl-4 text-[10px] text-slate-700 space-y-1 font-normal">
                {certifications.map((c) => (
                  <li key={c.id}>
                    <span className="font-bold">{c.name}</span> — <span className="italic">{c.issuer}</span> ({c.year})
                  </li>
                ))}
              </ul>
            </div>
          )}

          {languages && languages.length > 0 && (
            <div>
              <h3 className="font-extrabold text-[10.5px] uppercase tracking-wider text-slate-950 mb-1.5">FOREIGN LANGUAGES</h3>
              <ul className="list-disc pl-4 text-[10px] text-slate-700 space-y-1 font-normal">
                {languages.map((l) => (
                  <li key={l.id}>
                    <span className="font-bold">{l.name}</span> — <span className="italic">{l.proficiency}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
