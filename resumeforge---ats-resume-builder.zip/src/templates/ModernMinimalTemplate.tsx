/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ResumeData } from "../types";

interface TemplateProps {
  data: ResumeData;
}

export const ModernMinimalTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, summary, experience, education, skills, projects, certifications, languages } = data;

  return (
    <div
      className="bg-white text-slate-800 p-8 sm:p-10 mx-auto font-sans text-[11px] leading-relaxed shadow-inner flex flex-col md:flex-row gap-6 border-l-8 border-indigo-600"
      style={{ fontFamily: "'Inter', system-ui, sans-serif" }}
    >
      {/* LEFT COLUMN - Sidebar Personal, Skills, Education, Languages */}
      <div className="w-full md:w-1/3 flex flex-col gap-5 border-b md:border-b-0 md:border-r border-slate-100 pb-5 md:pb-0 md:pr-4">
        {/* Profile Details */}
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 leading-none">
            {personalInfo.name || "YOUR NAME"}
          </h1>
          <p className="text-[10px] uppercase font-bold tracking-wider text-indigo-600 mt-1">
            Candidate Profile
          </p>
        </div>

        {/* Contacts details list */}
        <div className="flex flex-col gap-1.5 text-[10px] break-all border-t border-slate-150 pt-3">
          {personalInfo.email && (
            <div>
              <span className="font-bold block text-[8px] uppercase tracking-wide text-slate-400">Email</span>
              <span className="text-slate-700">{personalInfo.email}</span>
            </div>
          )}
          {personalInfo.phone && (
            <div className="mt-1">
              <span className="font-bold block text-[8px] uppercase tracking-wide text-slate-400">Contact</span>
              <span className="text-slate-700">{personalInfo.phone}</span>
            </div>
          )}
          {personalInfo.linkedin && (
            <div className="mt-1">
              <span className="font-bold block text-[8px] uppercase tracking-wide text-slate-400">LinkedIn</span>
              <span className="text-indigo-600 hover:underline">{personalInfo.linkedin}</span>
            </div>
          )}
          {personalInfo.github && (
            <div className="mt-1">
              <span className="font-bold block text-[8px] uppercase tracking-wide text-slate-400">GitHub</span>
              <span className="text-indigo-600 hover:underline">{personalInfo.github}</span>
            </div>
          )}
          {personalInfo.portfolio && (
            <div className="mt-1">
              <span className="font-bold block text-[8px] uppercase tracking-wide text-slate-400">Portfolio</span>
              <span className="text-indigo-600 hover:underline">{personalInfo.portfolio}</span>
            </div>
          )}
        </div>

        {/* Education Sidebar entry */}
        {education && education.length > 0 && (
          <div className="border-t border-slate-150 pt-3">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 mb-2">Education</h3>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.id} className="leading-tight">
                  <span className="font-bold text-slate-900 block">{edu.institution}</span>
                  <span className="text-slate-700 text-[10px] block mt-0.5">{edu.degree}</span>
                  <span className="text-slate-500 text-[9px] block italic mt-0.5">
                    {edu.year} {edu.gpa ? ` | GPA: ${edu.gpa}` : ""}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Core skills sidebar */}
        {skills && skills.length > 0 && (
          <div className="border-t border-slate-150 pt-3">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 mb-2">Capabilities</h3>
            <div className="flex flex-wrap gap-1">
              {skills.map((skill) => (
                <span
                  key={skill}
                  className="bg-slate-100 text-slate-850 px-1.5 py-0.5 rounded text-[9px] font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Languages sidebar */}
        {languages && languages.length > 0 && (
          <div className="border-t border-slate-150 pt-3">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 mb-1.5">Languages</h3>
            <div className="space-y-1">
              {languages.map((l) => (
                <div key={l.id} className="text-[9.5px]">
                  <span className="font-bold text-slate-800">{l.name}</span> —{" "}
                  <span className="text-slate-500 italic">{l.proficiency}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* RIGHT COLUMN - Professional summaries, experience, projects, certifications */}
      <div className="w-full md:w-2/3 flex flex-col gap-5">
        {/* Professional Summary */}
        {summary && (
          <div>
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 border-b border-slate-100 pb-1 mb-2">
              Professional Summary
            </h3>
            <p className="text-justify text-[10.5px] leading-relaxed text-slate-700">
              {summary}
            </p>
          </div>
        )}

        {/* Work Experience list */}
        {experience && experience.length > 0 && (
          <div>
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 border-b border-slate-100 pb-1 mb-3 bg-white">
              Professional History
            </h3>
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-extrabold text-slate-900 text-[11.5px]">
                        {exp.title || "Job Title"}
                      </span>
                      <span className="text-slate-550 font-normal block text-[10.5px]">
                        {exp.company} {exp.location ? ` | ${exp.location}` : ""}
                      </span>
                    </div>
                    <span className="text-[9px] font-mono font-medium text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded">
                      {exp.duration}
                    </span>
                  </div>
                  {exp.bulletPoints && exp.bulletPoints.length > 0 && (
                    <ul className="list-disc pl-4 mt-2 space-y-0.5 text-[10px] text-slate-600 text-justify">
                      {exp.bulletPoints.map((bullet, idx) => (
                        bullet && <li key={idx} className="marker:text-indigo-400">{bullet}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects segment */}
        {projects && projects.length > 0 && (
          <div>
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 border-b border-slate-100 pb-1 mb-3">
              Technical Outputs
            </h3>
            <div className="space-y-3.5">
              {projects.map((proj) => (
                <div key={proj.id} className="relative pl-3 border-l border-indigo-200">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-900 text-[10.5px]">
                      {proj.name}
                    </span>
                    {proj.githubLink && (
                      <span className="text-[9px] text-indigo-500 underline hover:text-indigo-700 leading-none">
                        {proj.githubLink}
                      </span>
                    )}
                  </div>
                  <div className="text-[9px] text-indigo-600 font-mono font-semibold py-0.5">
                    Stack: {proj.techStack}
                  </div>
                  {proj.description && (
                    <p className="text-[10px] text-slate-600 text-justify mt-1">
                      {proj.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Certifications sidebar wrapper (if present) */}
        {certifications && certifications.length > 0 && (
          <div className="mt-2.5">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 border-b border-slate-100 pb-1 mb-2">
              Credentials
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {certifications.map((c) => (
                <div key={c.id} className="bg-slate-50 p-2 rounded border border-slate-100">
                  <span className="font-bold text-slate-800 block text-[10px]">{c.name}</span>
                  <span className="text-slate-500 text-[9px] block italic mt-0.5">{c.issuer} ({c.year})</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
