/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ResumeData } from "../types";

interface TemplateProps {
  data: ResumeData;
}

export const StudentFreshTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, summary, experience, education, skills, projects, certifications, languages } = data;

  return (
    <div
      className="bg-white text-slate-800 p-8 sm:p-10 mx-auto font-sans text-xs leading-relaxed shadow-inner max-w-4xl"
      style={{ fontFamily: "'Inter', system-ui, sans-serif" }}
    >
      {/* Dynamic Academic Style Header */}
      <div className="border-b border-indigo-200 pb-4 mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-extrabold text-indigo-900 tracking-tight">
            {personalInfo.name || "YOUR NAME"}
          </h1>
          <p className="text-xs font-semibold text-indigo-600 tracking-wide">
            Computer Science & Engineering Scholar
          </p>
        </div>
        <div className="text-[10px] sm:text-right text-slate-500 font-medium grid grid-cols-1 gap-0.5 mt-2 sm:mt-0">
          {personalInfo.email && <span className="hover:text-indigo-600 transition-colors">{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          <div className="flex gap-2 sm:justify-end mt-1 font-semibold text-indigo-700">
            {personalInfo.linkedin && <span className="underline">{personalInfo.linkedin}</span>}
            {personalInfo.github && <span className="underline">{personalInfo.github}</span>}
          </div>
        </div>
      </div>

      {/* Abstract profile */}
      {summary && (
        <div className="mb-5">
          <p className="text-[10.5px] text-slate-655 text-justify italic">
            "{summary}"
          </p>
        </div>
      )}

      {/* 🎓 FIRST CONVEC: EDUCATION HIGHLIGHTS */}
      {education && education.length > 0 && (
        <div className="mb-5 bg-indigo-50/20 p-3 rounded-lg border border-indigo-100/50">
          <h2 className="text-[10.5px] font-extrabold uppercase tracking-widest text-indigo-900 mb-2">
            Education (Core Credentials)
          </h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-start text-[10.5px]">
                <div>
                  <span className="font-extrabold text-slate-900 block">{edu.institution}</span>
                  <span className="text-indigo-800 font-medium block mt-0.5">
                    {edu.degree} {edu.gpa ? `— Current GPA: ${edu.gpa}` : ""}
                  </span>
                </div>
                <div className="text-right text-[10px]">
                  <span className="font-bold text-slate-600 block">{edu.year}</span>
                  <span className="text-slate-400 block italic">{edu.location}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 🚀 SECOND CONVEC: ACADEMIC PROJECTS */}
      {projects && projects.length > 0 && (
        <div className="mb-5">
          <h2 className="text-[10.5px] font-extrabold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-2">
            Academic & Capstone Projects
          </h2>
          <div className="space-y-3.5">
            {projects.map((proj) => (
              <div key={proj.id} className="p-2 border border-slate-50 hover:border-indigo-100 hover:bg-slate-50/40 rounded-lg transition-colors">
                <div className="flex justify-between font-bold text-[10.5px] text-indigo-950">
                  <span>
                    {proj.name}
                  </span>
                  {proj.githubLink && (
                    <span className="text-[9.5px] font-normal text-indigo-600 underline">
                      {proj.githubLink}
                    </span>
                  )}
                </div>
                <div className="text-[9px] text-slate-500 font-normal font-mono mt-0.5">
                  Stack: {proj.techStack}
                </div>
                {proj.description && (
                  <p className="text-[10px] text-slate-650 text-justify mt-1">
                    {proj.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 💼 THIRD CONVEC: WORK HISTORY */}
      {experience && experience.length > 0 && (
        <div className="mb-5">
          <h2 className="text-[10.5px] font-extrabold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-2">
            Work & Leadership Experience
          </h2>
          <div className="space-y-3.5">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start font-bold text-[10.5px] text-slate-900">
                  <span>
                    {exp.title} — <span className="font-normal text-slate-600 italic">{exp.company}</span>
                  </span>
                  <span className="text-[9px] font-medium text-indigo-600">{exp.duration}</span>
                </div>
                {exp.location && (
                  <div className="text-[9.5px] text-slate-400 italic">
                    {exp.location}
                  </div>
                )}
                {exp.bulletPoints && exp.bulletPoints.length > 0 && (
                  <ul className="list-disc pl-4 mt-1 space-y-0.5 text-[10px] text-slate-600 text-justify">
                    {exp.bulletPoints.map((bullet, idx) => (
                      bullet && <li key={idx}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 🧭 FOURTH CONVEC: SKILLS MATRIX */}
      {skills && skills.length > 0 && (
        <div className="mb-5">
          <h2 className="text-[10.5px] font-extrabold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-2">
            Core Competencies & Keywords
          </h2>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {skills.map((skill) => (
              <span
                key={skill}
                className="bg-indigo-50 text-indigo-900 border border-indigo-100 font-semibold px-2.5 py-0.5 rounded text-[10px]"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Certifications and Languages Grid style */}
      {(certifications?.length > 0 || languages?.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100 pt-3">
          {certifications && certifications.length > 0 && (
            <div>
              <h3 className="font-bold text-[10px] uppercase tracking-wider text-indigo-900 mb-1">Certifications</h3>
              <ul className="list-disc pl-4 text-[9.5px] text-slate-600 space-y-0.5">
                {certifications.map((c) => (
                  <li key={c.id}>
                    <span className="font-bold text-slate-800">{c.name}</span> — <span className="italic">{c.issuer}</span> ({c.year})
                  </li>
                ))}
              </ul>
            </div>
          )}

          {languages && languages.length > 0 && (
            <div>
              <h3 className="font-bold text-[10px] uppercase tracking-wider text-indigo-900 mb-1">Languages</h3>
              <ul className="list-disc pl-4 text-[9.5px] text-slate-600 space-y-0.5">
                {languages.map((l) => (
                  <li key={l.id}>
                    <span className="font-bold text-slate-850">{l.name}</span> — <span className="italic text-slate-500">{l.proficiency}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
