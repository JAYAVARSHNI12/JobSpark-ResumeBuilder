/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PersonalInfo {
  name: string;
  email: string;
  phone: string;
  linkedin: string;
  github: string;
  portfolio: string;
}

export interface WorkExperience {
  id: string;
  title: string;
  company: string;
  location: string;
  duration: string; // e.g. "June 2024 - Present" or "2022 - 2023"
  bulletPoints: string[]; // List of description bullets
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  location: string;
  year: string; // e.g. "2026" or "Expected Graduation 2026"
  gpa: string; // optional or custom string
}

export interface Project {
  id: string;
  name: string;
  techStack: string; // e.g. "React, Node, Firebase"
  description: string; // e.g. bullet description
  githubLink: string; // optional link
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  year: string;
}

export interface Language {
  id: string;
  name: string;
  proficiency: string; // e.g. "Native", "Fluent", "Conversational"
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  summary: string;
  experience: WorkExperience[];
  education: Education[];
  skills: string[]; // tag-based simple string array
  projects: Project[];
  certifications: Certification[];
  languages: Language[];
}

export interface ResumeDocument {
  id: string;
  userId: string;
  title: string;
  templateId: string;
  resumeData: ResumeData;
  createdAt: string;
  updatedAt: string;
}

// Initializing empty resume structure
export const INITIAL_RESUME_DATA: ResumeData = {
  personalInfo: {
    name: "",
    email: "",
    phone: "",
    linkedin: "",
    github: "",
    portfolio: ""
  },
  summary: "",
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
  languages: []
};

// High-quality CS project mock values (so user isn't presented with a fully blank sheet immediately)
export const SAMPLE_RESUME_DATA: ResumeData = {
  personalInfo: {
    name: "Alex Mercer",
    email: "alex.mercer@university.edu",
    phone: "+1 (555) 789-2345",
    linkedin: "linkedin.com/in/alex-mercer",
    github: "github.com/alex-mercer",
    portfolio: "alexmercer.dev"
  },
  summary: "Results-driven Computer Science undergraduate with experience developing scalable full-stack web applications and automation tools. Proficient in TypeScript, React, and Python, with a strong foundation in modern software development methodologies, agile workflows, and direct cloud setups.",
  experience: [
    {
      id: "exp-1",
      title: "Software Engineer Intern",
      company: "InnovateTech Solutions",
      location: "San Jose, CA",
      duration: "May 2025 - August 2025",
      bulletPoints: [
        "Collaborated in a team of 4 to refactor an obsolete React-based dashboard into a streamlined TypeScript platform, speeding up average load time by 32%.",
        "Designed and integrated 12+ secure RESTful API routes using Node.js and Express to securely fetch data from AWS databases.",
        "Authored 25+ unit tests using Jest, achieving a code coverage threshold of 88% overall."
      ]
    },
    {
      id: "exp-2",
      title: "Undergraduate TA (Data Structures)",
      company: "Department of Computer Science",
      location: "University Campus",
      duration: "September 2024 - May 2025",
      bulletPoints: [
        "Conducted bi-weekly recitation lessons reviewing linear data structures, heaps, graphs, sorting strategies, and recursive paradigms to over 40 students.",
        "Constructed automated grading scripts in Python, trimming manual grading overheads by roughly 10 hours per assignment."
      ]
    }
  ],
  education: [
    {
      id: "edu-1",
      degree: "B.S. in Computer Science",
      institution: "State Tech University",
      location: "Metro City",
      year: "Expected May 2027",
      gpa: "3.85 / 4.0"
    }
  ],
  skills: [
    "JavaScript", "TypeScript", "React", "Node.js", "Express", "Python",
    "Tailwind CSS", "Firebase", "SQL", "Git && Github", "Data Structures", "REST APIs"
  ],
  projects: [
    {
      id: "proj-1",
      name: "ResumeForge - ATS Builder App",
      techStack: "React, TypeScript, Firebase, Tailwind CSS",
      description: "Implemented a full-stack resume architect app providing clean structural templates, reactive rendering, ATS scoring optimization matrices, and persistent browser storage.",
      githubLink: "github.com/alex-mercer/resumeforge"
    },
    {
      id: "proj-2",
      name: "SocialSync - Real-time Chat App",
      techStack: "React, Firebase Cloud Firestore, Tailwind",
      description: "Crafted a live chat app featuring instant messaging, user presence monitors, rich emojis support, and fully secure routes.",
      githubLink: "github.com/alex-mercer/socialsync"
    }
  ],
  certifications: [
    {
      id: "cert-1",
      name: "AWS Certified Developer – Associate",
      issuer: "Amazon Web Services",
      year: "2025"
    }
  ],
  languages: [
    {
      id: "lang-1",
      name: "English",
      proficiency: "Native"
    },
    {
      id: "lang-2",
      name: "Spanish",
      proficiency: "Conversational"
    }
  ]
};
